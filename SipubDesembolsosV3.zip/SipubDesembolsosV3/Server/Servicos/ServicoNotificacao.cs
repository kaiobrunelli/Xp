using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using SipubDesembolsos.Server.Data;
using SipubDesembolsos.Server.Entidades;
using SipubDesembolsos.Server.Hubs;
using SipubDesembolsos.Shared;

namespace SipubDesembolsos.Server.Servicos;

public class ServicoNotificacao(AppDbContext db, IHubContext<HubNotificacao> hub)
{
    // ──────────────────────────────────────────────────────────────────────────
    // ENVIO
    // ──────────────────────────────────────────────────────────────────────────

    public async Task EnviarGeralAsync(string titulo, string descricao, string tipo, string? modulo = null, string? entidadeId = null, int? dias = null, int? horas = null)
    {
        var notif = new Notificacao
        {
            Titulo = titulo,
            Descricao = descricao,
            Tipo = tipo,
            Escopo = "Geral",
            Modulo = modulo,
            EntidadeId = entidadeId,
            ExpiraEm = CalcularExpiracao(dias, horas)
        };
        db.Notificacoes.Add(notif);
        await db.SaveChangesAsync();

        await hub.Clients.All.SendAsync("ReceberNotificacao", ToMensagem(notif));
    }

    public async Task EnviarIndividualAsync(string titulo, string descricao, string tipo, string usuarioId, string? modulo = null, string? entidadeId = null, int? dias = null, int? horas = null)
    {
        var notif = new Notificacao
        {
            Titulo = titulo,
            Descricao = descricao,
            Tipo = tipo,
            Escopo = "Individual",
            Modulo = modulo,
            EntidadeId = entidadeId,
            ExpiraEm = CalcularExpiracao(dias, horas),
            Destinatarios =
            [
                new NotificacaoUsuario { UsuarioId = usuarioId }
            ]
        };
        db.Notificacoes.Add(notif);
        await db.SaveChangesAsync();

        await hub.Clients.Group(usuarioId).SendAsync("ReceberNotificacao", ToMensagem(notif));
    }

    // ──────────────────────────────────────────────────────────────────────────
    // CONSULTAS
    // ──────────────────────────────────────────────────────────────────────────


  
    public async Task<List<NotificacaoDto>> ObterMinhasAsync(string usuarioId, int limite = 50)
    {
        return await db.Notificacoes
            .Where(n =>
                n.ExpiraEm > DateTime.UtcNow &&
                (n.Escopo == "Geral" ||
                 (n.Escopo == "Individual" && n.Destinatarios.Any(d => d.UsuarioId == usuarioId))))
            .OrderByDescending(n => n.CriadaEm)
            .Take(limite)
            .Select(n => new NotificacaoDto
            {
                Id = n.Id,
                Titulo = n.Titulo,
                Descricao = n.Descricao,
                Tipo = n.Tipo,
                Escopo = n.Escopo,
                CriadaEm = n.CriadaEm,
                DesembolsoId = n.EntidadeId,
                Lida = n.Destinatarios
                             .Where(d => d.UsuarioId == usuarioId)
                             .Select(d => (bool?)d.Lida)
                             .FirstOrDefault() ?? false
            })
            .AsNoTracking()
            .ToListAsync();
    }
 
    public async Task<int> ContarNaoLidasAsync(string usuarioId)
    {
        // Gerais não lidas: não tem row OU tem row com Lida=false (excluindo expiradas)
        var geralNaoLidas = await db.Notificacoes
            .Where(n => n.Escopo == "Geral" && n.ExpiraEm > DateTime.UtcNow)
            .CountAsync(n => !n.Destinatarios.Any(d => d.UsuarioId == usuarioId && d.Lida));

        // Individuais não lidas (excluindo expiradas)
        var individualNaoLidas = await db.NotificacoesUsuario
            .Where(nu => nu.UsuarioId == usuarioId && !nu.Lida
                         && nu.Notificacao.ExpiraEm > DateTime.UtcNow)
            .CountAsync();

        return geralNaoLidas + individualNaoLidas;
    }

    // ──────────────────────────────────────────────────────────────────────────
    // MARCAR COMO LIDA
    // ──────────────────────────────────────────────────────────────────────────

    public async Task<bool> MarcarLidaAsync(int notificacaoId, string usuarioId)
    {
        var nu = await db.NotificacoesUsuario
            .FirstOrDefaultAsync(x => x.NotificacaoId == notificacaoId && x.UsuarioId == usuarioId);

        if (nu is null)
        {
            // Lazy creation (notificação Geral ainda sem row para este usuário)
            var existe = await db.Notificacoes.AnyAsync(n => n.Id == notificacaoId);
            if (!existe) return false;

            db.NotificacoesUsuario.Add(new NotificacaoUsuario
            {
                NotificacaoId = notificacaoId,
                UsuarioId = usuarioId,
                Lida = true,
                LidaEm = DateTime.UtcNow
            });
        }
        else
        {
            nu.Lida = true;
            nu.LidaEm = DateTime.UtcNow;
        }

        await db.SaveChangesAsync();
        return true;
    }

    public async Task MarcarTodasLidasAsync(string usuarioId)
    {
        var agora = DateTime.UtcNow;

        // IDs de todas as notificações visíveis para este usuário (excluindo expiradas)
        var notifIds = await db.Notificacoes
            .Where(n =>
                n.ExpiraEm > DateTime.UtcNow &&
                (n.Escopo == "Geral" ||
                 (n.Escopo == "Individual" && n.Destinatarios.Any(d => d.UsuarioId == usuarioId))))
            .Select(n => n.Id)
            .ToListAsync();

        // Rows já existentes para este usuário
        var existentes = await db.NotificacoesUsuario
            .Where(nu => nu.UsuarioId == usuarioId && notifIds.Contains(nu.NotificacaoId))
            .ToListAsync();

        var existentesIds = existentes.Select(x => x.NotificacaoId).ToHashSet();

        // Atualiza existentes
        foreach (var nu in existentes.Where(n => !n.Lida))
        {
            nu.Lida = true;
            nu.LidaEm = agora;
        }

        // Cria rows lazy para as gerais que ainda não têm row
        foreach (var id in notifIds.Where(id => !existentesIds.Contains(id)))
        {
            db.NotificacoesUsuario.Add(new NotificacaoUsuario
            {
                NotificacaoId = id,
                UsuarioId = usuarioId,
                Lida = true,
                LidaEm = agora
            });
        }

        await db.SaveChangesAsync();
    }

    // ──────────────────────────────────────────────────────────────────────────
    // HELPER
    // ──────────────────────────────────────────────────────────────────────────

    private static DateTime CalcularExpiracao(int? dias, int? horas)
    {
        if (dias is null && horas is null)
            return DateTime.UtcNow.AddDays(7); // padrão: 7 dias quando nenhum prazo for informado
        return DateTime.UtcNow.AddDays(dias ?? 0).AddHours(horas ?? 0);
    }

    private static MensagemNotificacao ToMensagem(Notificacao n) => new()
    {
        Id = n.Id,
        Titulo = n.Titulo,
        Descricao = n.Descricao,
        Tipo = n.Tipo,
        Escopo = n.Escopo,
        Timestamp = n.CriadaEm,
        ExpiraEm = n.ExpiraEm,
        DesembolsoId = n.EntidadeId
    };
}
