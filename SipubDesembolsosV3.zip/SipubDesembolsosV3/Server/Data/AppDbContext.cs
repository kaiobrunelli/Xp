using Microsoft.EntityFrameworkCore;
using SipubDesembolsos.Server.Entidades;

namespace SipubDesembolsos.Server.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Notificacao>        Notificacoes        => Set<Notificacao>();
    public DbSet<NotificacaoUsuario> NotificacoesUsuario => Set<NotificacaoUsuario>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Notificacao>(e =>
        {
            e.ToTable("Notificacao");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).UseIdentityColumn();
            e.Property(x => x.Titulo).HasMaxLength(200);
            e.Property(x => x.Descricao).HasMaxLength(1000);
            e.Property(x => x.Tipo).HasMaxLength(20);
            e.Property(x => x.Escopo).HasMaxLength(20);
            e.Property(x => x.Modulo).HasMaxLength(50);
            e.Property(x => x.EntidadeId).HasMaxLength(50);
        });

        modelBuilder.Entity<NotificacaoUsuario>(e =>
        {
            e.ToTable("NotificacaoUsuario");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).UseIdentityColumn();
            e.Property(x => x.UsuarioId).HasMaxLength(100);
            e.HasIndex(x => new { x.NotificacaoId, x.UsuarioId }).IsUnique();
            e.HasOne(x => x.Notificacao)
             .WithMany(n => n.Destinatarios)
             .HasForeignKey(x => x.NotificacaoId)
             .OnDelete(DeleteBehavior.Cascade);
        });
    }
}
