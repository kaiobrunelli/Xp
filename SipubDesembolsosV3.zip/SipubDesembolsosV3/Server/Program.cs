using Microsoft.EntityFrameworkCore;
using SipubDesembolsos.Server.Data;
using SipubDesembolsos.Server.Hubs;
using SipubDesembolsos.Server.Servicos;

var builder = WebApplication.CreateBuilder(args);

// EF Core — SQL Server
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddScoped<ServicoNotificacao>();

builder.Services.AddControllers();
builder.Services.AddSignalR();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new()
    {
        Title       = "SIPUB Desembolsos — API",
        Version     = "v1",
        Description = "API com SignalR + persistência de notificações no banco de dados."
    });
});

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        policy
            .SetIsOriginAllowed(_ => true)
            .AllowAnyHeader()
            .AllowAnyMethod()
            .AllowCredentials();
    });
});

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(options =>
    {
        options.SwaggerEndpoint("/swagger/v1/swagger.json", "SIPUB Desembolsos v1");
        options.RoutePrefix = "swagger";
        options.DocumentTitle = "SIPUB API — Swagger";
    });
}

app.UseCors();
app.UseAuthorization();
app.MapControllers();
app.MapHub<HubNotificacao>("/hubs/notificacao");

app.Run();
