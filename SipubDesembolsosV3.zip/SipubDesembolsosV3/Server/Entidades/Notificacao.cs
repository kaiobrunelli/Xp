namespace SipubDesembolsos.Server.Entidades;

public class Notificacao
{
    public int      Id          { get; set; }
    public string   Titulo      { get; set; } = "";
    public string   Descricao   { get; set; } = "";
    public string   Tipo        { get; set; } = "informacao"; // informacao | sucesso | alerta
    public string   Escopo      { get; set; } = "Individual"; // Geral | Individual
    public DateTime CriadaEm   { get; set; } = DateTime.UtcNow;
    public string?   Modulo      { get; set; }
    public string?   EntidadeId  { get; set; }
    public DateTime  ExpiraEm    { get; set; } = DateTime.UtcNow.AddDays(7);

    public List<NotificacaoUsuario> Destinatarios { get; set; } = [];
}
