namespace SipubDesembolsos.Server.Entidades;

public class NotificacaoUsuario
{
    public int       Id              { get; set; }
    public int       NotificacaoId   { get; set; }
    public Notificacao Notificacao   { get; set; } = null!;
    public string    UsuarioId       { get; set; } = "";
    public bool      Lida            { get; set; }
    public DateTime? LidaEm          { get; set; }
    public bool      EntregueViaHub  { get; set; }
}
