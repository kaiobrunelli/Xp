-- ============================================================
-- SIPUB Desembolsos — Sistema de Notificações Persistidas
-- Execute este script no SSMS conectado ao servidor local
-- ============================================================

USE master;
GO

IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'SipubNotificacoes')
BEGIN
    CREATE DATABASE SipubNotificacoes;
    PRINT 'Banco de dados SipubNotificacoes criado.';
END
ELSE
BEGIN
    PRINT 'Banco de dados SipubNotificacoes já existe.';
END
GO

USE SipubNotificacoes;
GO

-- ────────────────────────────────────────────────────────────
-- Tabela: Notificacao
-- Armazena o evento em si (1 linha por notificação)
-- Escopo: 'Geral' = para todos | 'Individual' = destinatário específico
-- ────────────────────────────────────────────────────────────
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Notificacao')
BEGIN
    CREATE TABLE Notificacao (
        Id          UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID(),
        Titulo      NVARCHAR(200)    NOT NULL,
        Descricao   NVARCHAR(1000)   NOT NULL,
        Tipo        NVARCHAR(20)     NOT NULL,   -- 'informacao' | 'sucesso' | 'alerta'
        Escopo      NVARCHAR(20)     NOT NULL DEFAULT 'Individual', -- 'Geral' | 'Individual'
        CriadaEm   DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        Modulo      NVARCHAR(50)     NULL,
        EntidadeId  NVARCHAR(50)     NULL,
        CONSTRAINT PK_Notificacao PRIMARY KEY (Id)
    );
    PRINT 'Tabela Notificacao criada.';
END
GO

-- ────────────────────────────────────────────────────────────
-- Tabela: NotificacaoUsuario
-- Rastreia o estado de leitura por usuário
-- - Notificações Individuais: row criada junto com a Notificacao
-- - Notificações Gerais: row criada de forma lazy ao marcar como lida
-- ────────────────────────────────────────────────────────────
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'NotificacaoUsuario')
BEGIN
    CREATE TABLE NotificacaoUsuario (
        Id              UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID(),
        NotificacaoId   UNIQUEIDENTIFIER NOT NULL,
        UsuarioId       NVARCHAR(100)    NOT NULL,
        Lida            BIT              NOT NULL DEFAULT 0,
        LidaEm          DATETIME2        NULL,
        EntregueViaHub  BIT              NOT NULL DEFAULT 0,
        CONSTRAINT PK_NotificacaoUsuario   PRIMARY KEY (Id),
        CONSTRAINT FK_NotifUsuario_Notif   FOREIGN KEY (NotificacaoId)
            REFERENCES Notificacao(Id) ON DELETE CASCADE,
        CONSTRAINT UQ_NotifUsuario_Unique  UNIQUE (NotificacaoId, UsuarioId)
    );
    PRINT 'Tabela NotificacaoUsuario criada.';
END
GO

-- Índice para busca rápida de não lidas por usuário
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_NotificacaoUsuario_UsuarioId_Lida')
BEGIN
    CREATE INDEX IX_NotificacaoUsuario_UsuarioId_Lida
        ON NotificacaoUsuario (UsuarioId, Lida)
        INCLUDE (NotificacaoId);
    PRINT 'Índice IX_NotificacaoUsuario_UsuarioId_Lida criado.';
END
GO

PRINT 'Script concluído com sucesso!';
GO
