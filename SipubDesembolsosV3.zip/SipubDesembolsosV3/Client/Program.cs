using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using SipubDesembolsos.Client;
using SipubDesembolsos.Client.Servicos;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

var urlServidor = builder.Configuration["ServidorUrl"] ?? "https://localhost:7001";

// HttpClient aponta para a API do servidor
builder.Services.AddScoped(_ => new HttpClient { BaseAddress = new Uri(urlServidor + "/") });

builder.Services.AddSingleton(_ => new ServicoNotificacaoHub(urlServidor));
builder.Services.AddSingleton<ServicoUsuario>();
builder.Services.AddSingleton<ServicoNavegacao>();
builder.Services.AddSingleton<ServicoComentarios>();

await builder.Build().RunAsync();
