namespace SipubDesembolsos.Client.Servicos;

/// <summary>
/// Broker de navegação entre componentes de layout (BarraSuperior)
/// e páginas (PaginaAnalise). Ao clicar em uma notificação de contrato,
/// BarraSuperior dispara AbrirContrato e PaginaAnalise abre o dialog.
/// </summary>
public class ServicoNavegacao
{
    public event Func<string, Task>? AoAbrirContrato;

    public async Task AbrirContratoAsync(string desembolsoId)
    {
        if (AoAbrirContrato is not null)
            await AoAbrirContrato.Invoke(desembolsoId);
    }
}
