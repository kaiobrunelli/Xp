using SipubDesembolsos.Client.Modelos;
using System.Globalization;

namespace SipubDesembolsos.Client.Servicos;

public static class ServicoMock
{
    private static readonly CultureInfo _culturaBR = new("pt-BR");

    // ──────────────────────────────────────────────────────────────────────────
    // FUNCIONÁRIOS
    // ──────────────────────────────────────────────────────────────────────────
    public static List<Funcionario> ObterFuncionarios() =>
    [
        new() { Id = 1, Nome = "Karina Souto",   Iniciais = "KS", Cor = "#005CA9" },
        new() { Id = 2, Nome = "Rafael Mendes",  Iniciais = "RM", Cor = "#6D28D9" },
        new() { Id = 3, Nome = "Ana Paula Lima", Iniciais = "AP", Cor = "#0E7490" },
        new() { Id = 4, Nome = "Bruno Costa",    Iniciais = "BC", Cor = "#065F46" },
        new() { Id = 5, Nome = "Tânia Ferreira", Iniciais = "TF", Cor = "#92400E" },
    ];

    // ──────────────────────────────────────────────────────────────────────────
    // DESEMBOLSOS
    // ──────────────────────────────────────────────────────────────────────────
    public static List<Desembolso> ObterDesembolsos() =>
    [
        new()
        {
            Id = "DSB-001", NumId = "0012483", Contrato = "0512.345/2022-01",
            Mutuario = "Prefeitura Municipal de Caruaru", Gigov = "GIGOV03",
            Valor = 1_450_000m, Fase = "2ª Medição",
            ValidacoesOk = 5, ValidacoesTotal = 10,
            Status = "pendencia",
            PrazoFinal = new DateTime(2026, 6, 19)   // +2 dias úteis — pendencia urgente
        },
        new()
        {
            Id = "DSB-002", NumId = "0012484", Contrato = "0512.346/2022-02",
            Mutuario = "Município de Campina Grande", Gigov = "GIGOV01",
            Valor = 870_000m, Fase = "1ª Medição",
            ValidacoesOk = 5, ValidacoesTotal = 10,
            Status = "pendente",
            PrazoFinal = new DateTime(2026, 6, 23)   // +4 dias úteis — analisar
        },
        new()
        {
            Id = "DSB-003", NumId = "0012485", Contrato = "0512.347/2022-03",
            Mutuario = "Prefeitura de Mossoró", Gigov = "GIGOV02",
            Valor = 2_100_000m, Fase = "3ª Medição",
            ValidacoesOk = 10, ValidacoesTotal = 10,
            Status = "aprovado",
            PrazoFinal = new DateTime(2026, 6, 30)   // +9 dias úteis — aprovado
        },
        new()
        {
            Id = "DSB-004", NumId = "0012486", Contrato = "0512.348/2022-04",
            Mutuario = "Município de Feira de Santana", Gigov = "GIGOV05",
            Valor = 560_000m, Fase = "Final",
            ValidacoesOk = 3, ValidacoesTotal = 10,
            Status = "pendencia",
            PrazoFinal = new DateTime(2026, 6, 19)   // +2 dias úteis — pendencia crítica
        },
        new()
        {
            Id = "DSB-005", NumId = "0012487", Contrato = "0512.349/2022-05",
            Mutuario = "Prefeitura de Aracaju", Gigov = "GIGOV07",
            Valor = 1_230_000m, Fase = "1ª Medição",
            ValidacoesOk = 8, ValidacoesTotal = 10,
            Status = "pendente",
            PrazoFinal = new DateTime(2026, 6, 24)   // +5 dias úteis — analisar
        },
        new()
        {
            Id = "DSB-006", NumId = "0012488", Contrato = "0512.350/2022-06",
            Mutuario = "Município de Maceió", Gigov = "GIGOV04",
            Valor = 3_400_000m, Fase = "2ª Medição",
            ValidacoesOk = 10, ValidacoesTotal = 10,
            Status = "aprovado",
            PrazoFinal = new DateTime(2026, 7, 1)    // +10 dias úteis — aprovado
        },
    ];

    // ──────────────────────────────────────────────────────────────────────────
    // VALIDAÇÕES — conjunto distinto por desembolso
    // ──────────────────────────────────────────────────────────────────────────
    public static List<Validacao> ObterValidacoes(string idDesembolso = "DSB-001") => idDesembolso switch
    {
        "DSB-002" => ValidacoesDSB002(),
        "DSB-003" => ValidacoesDSB003(),
        "DSB-004" => ValidacoesDSB004(),
        "DSB-005" => ValidacoesDSB005(),
        "DSB-006" => ValidacoesDSB006(),
        _         => ValidacoesDSB001()
    };

    // DSB-001 — Caruaru — 2ª Medição — pendencia (2 inválido, 3 analisar, 5 válido)
    private static List<Validacao> ValidacoesDSB001() =>
    [
        new() { Numero = 1,  Titulo = "CND Municipal",                     Status = "valido",   Icone = "bi-building",
                Resultado = "Certidão válida — emitida em 03/03/2025, vence em 03/09/2025",
                Detalhe   = "A CND Municipal foi emitida pela Prefeitura de Caruaru em 03/03/2025 com validade de 180 dias. Nenhum débito pendente junto ao município." },
        new() { Numero = 2,  Titulo = "Certidão INSS",                     Status = "valido",   Icone = "bi-shield-check",
                Resultado = "Certidão válida — emitida em 15/02/2025",
                Detalhe   = "CND obtida via Receita Federal, vigente. Não há débitos previdenciários em aberto." },
        new() { Numero = 3,  Titulo = "Percentual de Desembolso",          Status = "pendente", Icone = "bi-percent",
                Resultado = "Percentual acima do limite — 62% vs. máx. 60%",
                Detalhe   = "O percentual acumulado de desembolso (62%) excede o limite máximo permitido para a 2ª fase (60%). Em análise para adequação.",
                SubItens  =
                [
                    new() { Numero = "3.1", Titulo = "Percentual Acumulado de Obra", Status = "valido",   Detalhe = "Medição acumulada de obra corresponde a 58% do total contratado, dentro da faixa esperada." },
                    new() { Numero = "3.2", Titulo = "Percentual Máximo por Fase",   Status = "invalido", Detalhe = "O limite para a 2ª medição é 60%. O valor solicitado (62%) ultrapassa esse teto." },
                    new() { Numero = "3.3", Titulo = "Consistência Acumulada",       Status = "valido",   Detalhe = "Valores acumulados de desembolso são consistentes com medições anteriores." },
                ] },
        new() { Numero = 4,  Titulo = "Sequência de Desembolso",           Status = "valido",   Icone = "bi-list-ol",
                Resultado = "Sequência correta — 2º desembolso após 1º aprovado",
                Detalhe   = "O 1º desembolso foi aprovado em 12/11/2024. O 2º está sendo solicitado dentro do prazo regulamentar." },
        new() { Numero = 5,  Titulo = "Regularidade FGTS do Mutuário",     Status = "pendente", Icone = "bi-person-check",
                Resultado = "Aguardando confirmação de regularidade junto ao FGTS",
                Detalhe   = "Certidão de regularidade FGTS solicitada em 01/04/2025. Aguardando retorno do órgão para conclusão da análise." },
        new() { Numero = 6,  Titulo = "Laudo de Medição do Engenheiro",    Status = "pendente", Icone = "bi-file-earmark-text",
                Resultado = "Laudo recebido, em análise pela equipe técnica",
                Detalhe   = "O laudo assinado pelo RT encontra-se em análise pela equipe técnica para verificação de conformidade com o projeto original.",
                ComentarioPreenchido = new Comentario
                {
                    Tipo = "informativo", Autor = "Ana Lima", Setor = "CEFGA",
                    Texto = "Laudo encaminhado em 29/04/2025 para revisão técnica. Aguardando parecer de conformidade. Prazo estimado: até 20/05/2025.",
                    Timestamp = new DateTime(2025, 5, 2, 14, 15, 0)
                } },
        new() { Numero = 7,  Titulo = "Depósito de Contrapartida",         Status = "valido",   Icone = "bi-bank",
                Resultado = "Contrapartida depositada — R$ 290.000,00 em 05/04/2025",
                Detalhe   = "A contrapartida obrigatória de 20% foi depositada na conta vinculada em 05/04/2025, conforme comprovante anexado ao processo." },
        new() { Numero = 8,  Titulo = "Prazo Contratual",                  Status = "invalido", Icone = "bi-calendar-x",
                Resultado = "Contrato com prazo vencido — expirou em 30/03/2025",
                Detalhe   = "O prazo de execução contratual expirou em 30/03/2025. É necessário aditamento antes da liberação do desembolso." },
        new() { Numero = 9,  Titulo = "Regularidade Fiscal da Construtora",Status = "invalido", Icone = "bi-building-gear",
                Resultado = "Débito ativo de R$ 12.400,00 junto à SEFAZ-PE",
                Detalhe   = "A construtora apresenta débito ativo de R$ 12.400,00 junto à SEFAZ-PE (consulta em 02/05/2025). Liberação condicionada à regularização ou certidão positiva com efeito de negativa." },
        new() { Numero = 10, Titulo = "Comunicação ao SCPO",               Status = "valido",   Icone = "bi-send-check",
                Resultado = "Comunicação ao Ministério do Trabalho realizada em 10/04/2025",
                Detalhe   = "A comunicação ao SCPO foi realizada em 10/04/2025, dentro do prazo regulamentar." },
    ];

    // DSB-002 — Campina Grande — 1ª Medição — pendente (0 inválido, 5 analisar, 5 válido)
    private static List<Validacao> ValidacoesDSB002() =>
    [
        new() { Numero = 1,  Titulo = "CND Municipal",                     Status = "valido",   Icone = "bi-building",
                Resultado = "Certidão válida — emitida em 10/04/2025",
                Detalhe   = "A CND Municipal do Município de Campina Grande está vigente, emitida em 10/04/2025 com validade de 180 dias." },
        new() { Numero = 2,  Titulo = "Certidão INSS",                     Status = "valido",   Icone = "bi-shield-check",
                Resultado = "Certidão válida — sem débitos previdenciários",
                Detalhe   = "CND Previdenciária obtida via Receita Federal. Nenhum débito em aberto identificado." },
        new() { Numero = 3,  Titulo = "Sequência de Desembolso",           Status = "valido",   Icone = "bi-list-ol",
                Resultado = "1ª solicitação — sequência correta",
                Detalhe   = "Trata-se do primeiro desembolso do contrato. A documentação de início de obra foi apresentada conforme exigido." },
        new() { Numero = 4,  Titulo = "Depósito de Contrapartida",         Status = "valido",   Icone = "bi-bank",
                Resultado = "Contrapartida depositada — R$ 174.000,00 em 08/04/2025",
                Detalhe   = "A contrapartida de 20% do valor do investimento foi depositada em 08/04/2025 na conta vinculada ao contrato." },
        new() { Numero = 5,  Titulo = "Comunicação ao SCPO",               Status = "valido",   Icone = "bi-send-check",
                Resultado = "Comunicação ao Ministério do Trabalho realizada em 05/04/2025",
                Detalhe   = "O comunicado de início de obras ao SCPO foi enviado em 05/04/2025, dentro do prazo." },
        new() { Numero = 6,  Titulo = "Laudo de Medição do Engenheiro",    Status = "pendente", Icone = "bi-file-earmark-text",
                Resultado = "Laudo recebido em 22/04/2025 — em análise técnica",
                Detalhe   = "O laudo de medição da 1ª etapa foi recebido e encaminhado para revisão técnica. Aguardando parecer de conformidade com o projeto executivo." },
        new() { Numero = 7,  Titulo = "Percentual de Desembolso",          Status = "pendente", Icone = "bi-percent",
                Resultado = "Percentual sob análise — valor solicitado: 45%",
                Detalhe   = "O percentual de 45% solicitado para a 1ª medição está sendo verificado quanto ao avanço físico comprovado em obra.",
                SubItens  =
                [
                    new() { Numero = "7.1", Titulo = "Percentual Acumulado de Obra", Status = "valido",   Detalhe = "Medição de campo indica 47% de execução física, compatível com o percentual solicitado." },
                    new() { Numero = "7.2", Titulo = "Percentual Máximo por Fase",   Status = "pendente", Detalhe = "Verificação em andamento se o percentual solicitado respeita o teto previsto no cronograma contratual." },
                    new() { Numero = "7.3", Titulo = "Consistência Acumulada",       Status = "valido",   Detalhe = "Trata-se do primeiro desembolso — não há histórico acumulado a confrontar." },
                ] },
        new() { Numero = 8,  Titulo = "Regularidade FGTS do Mutuário",     Status = "pendente", Icone = "bi-person-check",
                Resultado = "Certidão FGTS solicitada — retorno pendente",
                Detalhe   = "A certidão de regularidade FGTS foi solicitada em 15/04/2025. O órgão ainda não emitiu o documento. Prazo esperado: 5 dias úteis." },
        new() { Numero = 9,  Titulo = "Regularidade Fiscal da Construtora", Status = "pendente", Icone = "bi-building-gear",
                Resultado = "Consulta à SEFAZ-PB em andamento",
                Detalhe   = "A consulta de regularidade fiscal da construtora junto à SEFAZ-PB foi iniciada em 18/04/2025. Resultado esperado até 25/04/2025." },
        new() { Numero = 10, Titulo = "Prazo Contratual",                   Status = "pendente", Icone = "bi-calendar-check",
                Resultado = "Prazo vigente — verificação de aditamento em andamento",
                Detalhe   = "O contrato vigora até 15/12/2025. Está sendo verificado se existe necessidade de aditamento para adequação do cronograma à medição solicitada." },
    ];

    // DSB-003 — Mossoró — 3ª Medição — aprovado (10 válido)
    private static List<Validacao> ValidacoesDSB003() =>
    [
        new() { Numero = 1,  Titulo = "CND Municipal",                     Status = "valido", Icone = "bi-building",
                Resultado = "Certidão válida — emitida em 20/01/2025",
                Detalhe   = "CND Municipal de Mossoró emitida em 20/01/2025, válida por 180 dias. Sem pendências junto ao município." },
        new() { Numero = 2,  Titulo = "Certidão INSS",                     Status = "valido", Icone = "bi-shield-check",
                Resultado = "Certidão válida — obtida em 18/01/2025",
                Detalhe   = "Regularidade previdenciária confirmada via Receita Federal. Nenhum débito identificado." },
        new() { Numero = 3,  Titulo = "Percentual de Desembolso",          Status = "valido", Icone = "bi-percent",
                Resultado = "Percentual de 78% dentro do limite para 3ª medição (máx. 80%)",
                Detalhe   = "O percentual acumulado de 78% está abaixo do teto de 80% previsto para a 3ª medição. Aprovado." },
        new() { Numero = 4,  Titulo = "Sequência de Desembolso",           Status = "valido", Icone = "bi-list-ol",
                Resultado = "3ª solicitação — sequência regular após 2ª medição aprovada em 10/11/2024",
                Detalhe   = "O 2º desembolso foi aprovado em 10/11/2024. O 3º está sendo solicitado dentro do prazo e em sequência correta." },
        new() { Numero = 5,  Titulo = "Regularidade FGTS do Mutuário",     Status = "valido", Icone = "bi-person-check",
                Resultado = "FGTS regular — certidão emitida em 02/02/2025",
                Detalhe   = "A Prefeitura de Mossoró apresenta regularidade plena junto ao FGTS. Certidão emitida em 02/02/2025." },
        new() { Numero = 6,  Titulo = "Laudo de Medição do Engenheiro",    Status = "valido", Icone = "bi-file-earmark-text",
                Resultado = "Laudo aprovado — 78% de execução física confirmada",
                Detalhe   = "O laudo do RT atesta 78% de execução física, compatível com o percentual solicitado. Sem ressalvas técnicas." },
        new() { Numero = 7,  Titulo = "Depósito de Contrapartida",         Status = "valido", Icone = "bi-bank",
                Resultado = "Contrapartida depositada — R$ 420.000,00 em 14/02/2025",
                Detalhe   = "Contrapartida de 20% depositada em 14/02/2025 na conta vinculada. Comprovante anexado e conferido." },
        new() { Numero = 8,  Titulo = "Prazo Contratual",                  Status = "valido", Icone = "bi-calendar-check",
                Resultado = "Contrato vigente até 30/06/2025",
                Detalhe   = "O contrato possui prazo vigente até 30/06/2025. Não há necessidade de aditamento neste momento." },
        new() { Numero = 9,  Titulo = "Regularidade Fiscal da Construtora",Status = "valido", Icone = "bi-building-gear",
                Resultado = "Construtora regular — sem débitos junto à SEFAZ-RN",
                Detalhe   = "Consulta à SEFAZ-RN em 05/02/2025 não identificou débitos em aberto. Construtora regularizada." },
        new() { Numero = 10, Titulo = "Comunicação ao SCPO",               Status = "valido", Icone = "bi-send-check",
                Resultado = "Comunicação da 3ª medição realizada em 20/02/2025",
                Detalhe   = "Comunicado da 3ª medição enviado ao SCPO em 20/02/2025, dentro do prazo regulamentar." },
    ];

    // DSB-004 — Feira de Santana — Final — pendencia (4 inválido, 3 analisar, 3 válido)
    private static List<Validacao> ValidacoesDSB004() =>
    [
        new() { Numero = 1,  Titulo = "CND Municipal",                     Status = "valido",   Icone = "bi-building",
                Resultado = "Certidão válida — emitida em 05/03/2025",
                Detalhe   = "CND Municipal de Feira de Santana emitida em 05/03/2025, válida até 01/09/2025. Sem pendências." },
        new() { Numero = 2,  Titulo = "Certidão INSS",                     Status = "invalido", Icone = "bi-shield-x",
                Resultado = "Certidão INSS vencida — expirou em 28/02/2025",
                Detalhe   = "A CND Previdenciária venceu em 28/02/2025 e não foi renovada. É necessário obter nova certidão antes da liberação." },
        new() { Numero = 3,  Titulo = "Percentual de Desembolso",          Status = "invalido", Icone = "bi-percent",
                Resultado = "Percentual acumulado de 95% excede o limite final de 90%",
                Detalhe   = "O percentual acumulado total solicitado (95%) ultrapassa o limite máximo previsto para o desembolso final (90%). Necessário ajuste no valor solicitado." },
        new() { Numero = 4,  Titulo = "Sequência de Desembolso",           Status = "valido",   Icone = "bi-list-ol",
                Resultado = "Desembolso final — sequência regular após parcelas anteriores aprovadas",
                Detalhe   = "As medições anteriores foram todas aprovadas regularmente. A solicitação final segue a sequência correta." },
        new() { Numero = 5,  Titulo = "Prazo Contratual",                  Status = "invalido", Icone = "bi-calendar-x",
                Resultado = "Contrato vencido em 08/05/2025 — sem aditamento vigente",
                Detalhe   = "O prazo de execução expirou em 08/05/2025. Não há aditamento vigente que cubra o período atual. Regularização obrigatória antes do pagamento." },
        new() { Numero = 6,  Titulo = "Regularidade FGTS do Mutuário",     Status = "pendente", Icone = "bi-person-check",
                Resultado = "Certidão FGTS com recurso administrativo em andamento",
                Detalhe   = "Existe um recurso administrativo junto ao FGTS sobre o saldo devedor do município. Aguardando decisão do órgão para confirmar regularidade." },
        new() { Numero = 7,  Titulo = "Laudo de Medição do Engenheiro",    Status = "invalido", Icone = "bi-file-earmark-text",
                Resultado = "Laudo com divergência — execução física declarada não confere com vistoria de campo",
                Detalhe   = "A vistoria de campo realizada em 29/04/2025 identificou execução física de 87%, enquanto o laudo declara 95%. A divergência impede a liberação." },
        new() { Numero = 8,  Titulo = "Depósito de Contrapartida",         Status = "valido",   Icone = "bi-bank",
                Resultado = "Contrapartida integral depositada — R$ 112.000,00 em 01/04/2025",
                Detalhe   = "A contrapartida final foi depositada integralmente em 01/04/2025. Comprovante verificado e conferido." },
        new() { Numero = 9,  Titulo = "Regularidade Fiscal da Construtora",Status = "pendente", Icone = "bi-building-gear",
                Resultado = "Parcelamento de débito ativo junto à SEFAZ-BA em análise",
                Detalhe   = "A construtora possui débito junto à SEFAZ-BA com parcelamento em andamento. Aguardando comprovante de parcelas em dia para atestar regularidade." },
        new() { Numero = 10, Titulo = "Comunicação ao SCPO",               Status = "pendente", Icone = "bi-send-check",
                Resultado = "Comunicação final ao SCPO ainda não enviada",
                Detalhe   = "O comunicado de conclusão de obra ao SCPO ainda não foi enviado. Pendência que deve ser regularizada antes da liberação do desembolso final." },
    ];

    // DSB-005 — Aracaju — 1ª Medição — pendente (0 inválido, 2 analisar, 8 válido)
    private static List<Validacao> ValidacoesDSB005() =>
    [
        new() { Numero = 1,  Titulo = "CND Municipal",                     Status = "valido",   Icone = "bi-building",
                Resultado = "Certidão válida — emitida em 14/03/2025",
                Detalhe   = "CND Municipal de Aracaju emitida em 14/03/2025 com validade de 180 dias. Sem débitos municipais." },
        new() { Numero = 2,  Titulo = "Certidão INSS",                     Status = "valido",   Icone = "bi-shield-check",
                Resultado = "Certidão válida — obtida em 10/03/2025",
                Detalhe   = "Regularidade previdenciária confirmada. Certidão válida até 10/09/2025." },
        new() { Numero = 3,  Titulo = "Sequência de Desembolso",           Status = "valido",   Icone = "bi-list-ol",
                Resultado = "1ª solicitação — documentação de início de obra conferida",
                Detalhe   = "Primeiro desembolso do contrato. Documentação de início de obra e ART do RT apresentadas e conferidas." },
        new() { Numero = 4,  Titulo = "Percentual de Desembolso",          Status = "valido",   Icone = "bi-percent",
                Resultado = "Percentual de 38% dentro do limite para 1ª medição (máx. 40%)",
                Detalhe   = "O percentual de 38% solicitado está dentro do teto de 40% previsto para a 1ª medição. Aprovado." },
        new() { Numero = 5,  Titulo = "Regularidade FGTS do Mutuário",     Status = "valido",   Icone = "bi-person-check",
                Resultado = "FGTS regular — certidão emitida em 08/03/2025",
                Detalhe   = "A Prefeitura de Aracaju está regular junto ao FGTS. Certidão emitida em 08/03/2025." },
        new() { Numero = 6,  Titulo = "Depósito de Contrapartida",         Status = "valido",   Icone = "bi-bank",
                Resultado = "Contrapartida depositada — R$ 246.000,00 em 20/03/2025",
                Detalhe   = "Contrapartida de 20% depositada em 20/03/2025. Comprovante bancário verificado." },
        new() { Numero = 7,  Titulo = "Prazo Contratual",                  Status = "valido",   Icone = "bi-calendar-check",
                Resultado = "Contrato vigente até 30/09/2025",
                Detalhe   = "O contrato possui prazo vigente até 30/09/2025. Não há pendência de aditamento." },
        new() { Numero = 8,  Titulo = "Comunicação ao SCPO",               Status = "valido",   Icone = "bi-send-check",
                Resultado = "Comunicação de início de obras enviada em 15/03/2025",
                Detalhe   = "O comunicado de início de obras ao SCPO foi enviado em 15/03/2025, dentro do prazo." },
        new() { Numero = 9,  Titulo = "Laudo de Medição do Engenheiro",    Status = "pendente", Icone = "bi-file-earmark-text",
                Resultado = "Laudo recebido — aguardando validação técnica interna",
                Detalhe   = "O laudo da 1ª medição foi entregue pelo RT em 20/04/2025 e encaminhado para validação técnica interna. Prazo de resposta: 5 dias úteis.",
                ComentarioPreenchido = new Comentario
                {
                    Tipo = "informativo", Autor = "Ana Lima", Setor = "CEFGA",
                    Texto = "Laudo recebido e em fila de revisão. Verificação de conformidade com o projeto executivo estimada para até 28/04/2025.",
                    Timestamp = new DateTime(2025, 4, 21, 10, 0, 0)
                } },
        new() { Numero = 10, Titulo = "Regularidade Fiscal da Construtora",Status = "pendente", Icone = "bi-building-gear",
                Resultado = "Aguardando atualização da certidão estadual — SEFAZ-SE",
                Detalhe   = "A certidão estadual da construtora venceu em 18/04/2025. Nova certidão foi solicitada e deve ser apresentada em até 3 dias úteis." },
    ];

    // DSB-006 — Maceió — 2ª Medição — aprovado (10 válido)
    private static List<Validacao> ValidacoesDSB006() =>
    [
        new() { Numero = 1,  Titulo = "CND Municipal",                     Status = "valido", Icone = "bi-building",
                Resultado = "Certidão válida — emitida em 28/02/2025",
                Detalhe   = "CND Municipal de Maceió emitida em 28/02/2025, válida por 180 dias. Sem pendências." },
        new() { Numero = 2,  Titulo = "Certidão INSS",                     Status = "valido", Icone = "bi-shield-check",
                Resultado = "Certidão válida — obtida em 25/02/2025",
                Detalhe   = "Regularidade previdenciária confirmada. Nenhum débito em aberto." },
        new() { Numero = 3,  Titulo = "Percentual de Desembolso",          Status = "valido", Icone = "bi-percent",
                Resultado = "Percentual de 55% dentro do limite para 2ª medição (máx. 60%)",
                Detalhe   = "O percentual acumulado de 55% está abaixo do teto de 60% para a 2ª medição. Aprovado sem ressalvas." },
        new() { Numero = 4,  Titulo = "Sequência de Desembolso",           Status = "valido", Icone = "bi-list-ol",
                Resultado = "2ª solicitação — regular após 1ª medição aprovada em 05/12/2024",
                Detalhe   = "A 1ª medição foi aprovada em 05/12/2024. A 2ª está sendo solicitada dentro do prazo e em sequência regular." },
        new() { Numero = 5,  Titulo = "Regularidade FGTS do Mutuário",     Status = "valido", Icone = "bi-person-check",
                Resultado = "FGTS regular — certidão emitida em 03/03/2025",
                Detalhe   = "Prefeitura de Maceió regular junto ao FGTS. Certidão emitida em 03/03/2025." },
        new() { Numero = 6,  Titulo = "Laudo de Medição do Engenheiro",    Status = "valido", Icone = "bi-file-earmark-text",
                Resultado = "Laudo aprovado — 55% de execução física confirmada, sem ressalvas",
                Detalhe   = "O laudo do RT atesta 55% de execução física, condizente com o percentual solicitado. Sem divergências em relação ao projeto original." },
        new() { Numero = 7,  Titulo = "Depósito de Contrapartida",         Status = "valido", Icone = "bi-bank",
                Resultado = "Contrapartida depositada — R$ 680.000,00 em 10/03/2025",
                Detalhe   = "Contrapartida de 20% depositada integralmente em 10/03/2025. Comprovante conferido." },
        new() { Numero = 8,  Titulo = "Prazo Contratual",                  Status = "valido", Icone = "bi-calendar-check",
                Resultado = "Contrato vigente até 31/03/2026",
                Detalhe   = "O prazo contratual está vigente até 31/03/2026. Sem necessidade de aditamento." },
        new() { Numero = 9,  Titulo = "Regularidade Fiscal da Construtora",Status = "valido", Icone = "bi-building-gear",
                Resultado = "Construtora regular — sem débitos junto à SEFAZ-AL",
                Detalhe   = "Consulta à SEFAZ-AL em 05/03/2025 não identificou débitos. Construtora em situação regular." },
        new() { Numero = 10, Titulo = "Comunicação ao SCPO",               Status = "valido", Icone = "bi-send-check",
                Resultado = "Comunicação da 2ª medição realizada em 12/03/2025",
                Detalhe   = "Comunicado da 2ª medição enviado ao SCPO em 12/03/2025, dentro do prazo regulamentar." },
    ];

    // ──────────────────────────────────────────────────────────────────────────
    // DETALHE DO CONTRATO
    // ──────────────────────────────────────────────────────────────────────────
    public static DetalheContrato ObterDetalheContrato(Desembolso row)
    {
        if (row.Id == "DSB-001")
        {
            return new DetalheContrato
            {
                Id = "DSB-001",
                Gigov = "GIG-2022-04512",
                NumeroContrato = "0512.345/2022-01",
                Mutuario = new() { Nome = "Prefeitura Municipal de Caruaru", Tipo = "Município" },
                Af = new() { Nome = "Agência Nordeste — Recife", Sigla = "AF/REC" },
                Financiamento = new()
                {
                    Programa           = "Pró-Moradia",
                    ValorInvestimento  = 1_812_500m,
                    ValorFinanciamento = 1_450_000m,
                    NumeroDesembolso   = "2º",
                    Fase               = "2ª Medição",
                    PercentualObra     = 62m,
                    Amortizacao        = "SAC / TR",
                    PercentualContrapartida = 20m
                }
            };
        }

        // Gera dados plausíveis para os demais desembolsos
        var seed = row.Id.GetHashCode();
        var programas = new[] { "Pró-Moradia", "Saneamento", "Mobilidade Urbana", "Infraestrutura" };
        var afs = new[]
        {
            new DadosAf { Nome = "Agência Norte — Belém",       Sigla = "AF/BEL" },
            new DadosAf { Nome = "Agência Centro-Oeste — BSB",  Sigla = "AF/BSB" },
            new DadosAf { Nome = "Agência Sul — Porto Alegre",  Sigla = "AF/POA" },
        };

        return new DetalheContrato
        {
            Id             = row.Id,
            Gigov          = row.Gigov,
            NumeroContrato = row.Contrato,
            Mutuario       = new() { Nome = row.Mutuario, Tipo = "Município" },
            Af             = afs[Math.Abs(seed) % afs.Length],
            Financiamento  = new()
            {
                Programa           = programas[Math.Abs(seed) % programas.Length],
                ValorInvestimento  = row.Valor * 1.25m,
                ValorFinanciamento = row.Valor,
                NumeroDesembolso   = row.Fase.Contains("1") ? "1º" : row.Fase.Contains("2") ? "2º" : "3º",
                Fase               = row.Fase,
                PercentualObra     = 45m + (Math.Abs(seed) % 30),
                Amortizacao        = "SAC / TR",
                PercentualContrapartida = 20m
            }
        };
    }

    // ──────────────────────────────────────────────────────────────────────────
    // UTILITÁRIOS DE FORMATAÇÃO
    // ──────────────────────────────────────────────────────────────────────────
    public static string FormatarBRL(decimal valor) =>
        valor.ToString("C", _culturaBR);

    public static string FormatarPrazo(DateTime data)
    {
        string[] meses = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];
        return $"{data.Day} {meses[data.Month - 1]}";
    }

    public static string FormatarTempo(DateTime timestamp)
    {
        var diff = DateTime.Now - timestamp;
        if (diff.TotalMinutes < 1)   return "agora";
        if (diff.TotalMinutes < 60)  return $"{(int)diff.TotalMinutes}min atrás";
        if (diff.TotalHours   < 24)  return $"{(int)diff.TotalHours}h atrás";
        return timestamp.ToString("dd/MM/yyyy HH:mm");
    }
}
