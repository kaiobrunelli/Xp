using SipubDesembolsos.Client.Modelos;

namespace SipubDesembolsos.Client.Servicos;

/// <summary>
/// Mantém comentários em memória durante a sessão — sobrevive a trocas de usuário.
/// Chave composta: "{desembolsoId}:{chaveItem}" (ex: "DSB-001:v3-3.2")
/// </summary>
public class ServicoComentarios
{
    private readonly Dictionary<string, List<Comentario>> _dados = new();

    public List<Comentario> Obter(string desembolsoId, string chave)
    {
        _dados.TryGetValue(Compor(desembolsoId, chave), out var lista);
        return lista ?? [];
    }

    public void Adicionar(string desembolsoId, string chave, Comentario comentario)
    {
        var k = Compor(desembolsoId, chave);
        if (!_dados.ContainsKey(k))
            _dados[k] = [];
        _dados[k].Add(comentario);
    }

    public void InicializarSeVazio(string desembolsoId, string chave, Comentario comentario)
    {
        var k = Compor(desembolsoId, chave);
        if (!_dados.ContainsKey(k))
            _dados[k] = [comentario];
    }

    private static string Compor(string desembolsoId, string chave) => $"{desembolsoId}:{chave}";
}
