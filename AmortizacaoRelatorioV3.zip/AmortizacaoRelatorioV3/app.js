﻿/* ═══════════════════════════════════════════════════════════════
   Amortização Caixa — Relatório  |  app.js
   ═══════════════════════════════════════════════════════════════ */

'use strict';

Chart.register(ChartDataLabels);

/* ── state ──────────────────────────────────────────────────── */
const state = {
  chartType:    'line',
  activeAreas:  new Set(DATASET.areas.filter(a => a.id !== 'habitacao').map(a => a.id)),
  hiddenDatasets: new Set(),
  dateFrom:     new Date('2025-06-01'),
  dateTo:       new Date('2026-06-30'),
  granularity:  'monthly',
  showLabels:   false,
  tableSortCol: 'total',
  tableSortDir: 'desc',
};

let chartInstance = null;

/* ── ícones temáticos por área (stroke-based, viewBox 0 0 24 24) ── */
const AREA_ICONS = {
  saneamento:    '<path d="M12 2C8 8 5 13 5 16a7 7 0 0014 0c0-3-3-8-7-14z"/>',
  habitacao:     '<path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
  infraestrutura:'<rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/>',
  saude:         '<path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/>',
  promoradia:    '<path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><path d="M9 22v-6h6v6"/><circle cx="12" cy="11" r="2"/>',
  protransporte: '<rect x="1" y="3" width="15" height="13" rx="1"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/>',
};

/* ── helpers ─────────────────────────────────────────────────── */
const fmt = v => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 2 });

/* Abreviação profissional PT-BR (padrão mercado financeiro brasileiro):
   K = mil  |  M = milhão  |  Bi = bilhão
   Decimal com vírgula conforme ABNT/BCB: 1,1M · 180K · 2,5Bi */
const fmtShort = v => {
  if (v >= 1_000_000_000) return `R$ ${(v / 1_000_000_000).toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}Bi`;
  if (v >= 1_000_000)     return `R$ ${(v / 1_000_000).toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}M`;
  if (v >= 1_000)         return `R$ ${(v / 1_000).toLocaleString('pt-BR', { minimumFractionDigits: 0, maximumFractionDigits: 1 })} mil`;
  return fmt(v);
};

/* versão sem prefixo R$ para data labels inline no gráfico */
const fmtLabel = v => {
  if (v >= 1_000_000_000) return `${(v / 1_000_000_000).toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}Bi`;
  if (v >= 1_000_000)     return `${(v / 1_000_000).toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}M`;
  if (v >= 1_000)         return `${(v / 1_000).toLocaleString('pt-BR', { minimumFractionDigits: 0, maximumFractionDigits: 1 })} mil`;
  return v.toLocaleString('pt-BR');
};

/* Retorna o total absoluto do período imediatamente anterior (mesmo span).
   monthly: conta quantos meses há no período atual e volta essa quantidade.
   daily:   volta exatamente o mesmo número de dias. */
function calcPrevTotal(area, dateFrom, dateTo, granularity) {
  if (granularity === 'daily') {
    const spanMs   = dateTo.getTime() - dateFrom.getTime();
    const prevTo   = new Date(dateFrom.getTime() - 1);
    const prevFrom = new Date(prevTo.getTime() - spanMs);
    prevFrom.setHours(0, 0, 0, 0);
    const vals = area.dailyValues.filter(v => dateInRange(v.date, prevFrom, prevTo));
    const tot  = vals.reduce((s, v) => s + v.value, 0);
    return tot || null;
  }
  const currentMonths = area.monthlyValues.filter(v => dateInRange(v.date, dateFrom, dateTo));
  if (!currentMonths.length) return null;
  const count     = currentMonths.length;
  const firstDate = new Date(currentMonths[0].date + 'T00:00:00');
  const prevEnd   = new Date(firstDate.getFullYear(), firstDate.getMonth(), 0);
  const prevStart = new Date(prevEnd.getFullYear(), prevEnd.getMonth() - count + 1, 1);
  const prevVals  = area.monthlyValues.filter(v => dateInRange(v.date, prevStart, prevEnd));
  const tot = prevVals.reduce((s, v) => s + v.value, 0);
  return tot || null;
}

function makeTrendHtml(delta) {
  if (delta === null) return `<div class="kpi-trend kpi-trend--neutral">sem per. anterior</div>`;
  const arrow = delta >= 0 ? '↑' : '↓';
  const cls   = delta >= 0 ? 'kpi-trend--up' : 'kpi-trend--down';
  return `<div class="kpi-trend ${cls}">${arrow} ${Math.abs(delta).toFixed(1)}% vs. per. ant.</div>`;
}

function daysBetween(a, b) {
  return Math.round((b - a) / 86_400_000);
}

function detectGranularity(from, to) {
  return daysBetween(from, to) <= 45 ? 'daily' : 'monthly';
}

function dateInRange(dateStr, from, to) {
  const d = new Date(dateStr);
  return d >= from && d <= to;
}

/* ── filtered series ─────────────────────────────────────────── */
function getFilteredSeries() {
  const { dateFrom, dateTo, granularity, activeAreas } = state;

  const allDates = new Set();
  const seriesMap = {};

  DATASET.areas.forEach(area => {
    if (!activeAreas.has(area.id)) return;
    const values = granularity === 'daily' ? area.dailyValues : area.monthlyValues;
    const filtered = values.filter(v => dateInRange(v.date, dateFrom, dateTo));
    seriesMap[area.id] = filtered;
    filtered.forEach(v => allDates.add(v.date));
  });

  const labels = [...allDates].sort();

  return { labels, seriesMap };
}

/* ── chart label formatter ───────────────────────────────────── */
function formatLabel(dateStr, granularity) {
  const d = new Date(dateStr + 'T00:00:00');
  if (granularity === 'monthly') {
    return d.toLocaleDateString('pt-BR', { month: 'short', year: '2-digit' });
  }
  return d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
}

/* ── build chart datasets ────────────────────────────────────── */
function buildChartDatasets(labels, seriesMap) {
  return DATASET.areas
    .filter(a => state.activeAreas.has(a.id))
    .map(area => {
      const map = Object.fromEntries((seriesMap[area.id] || []).map(v => [v.date, v.value]));
      const data = labels.map(l => map[l] ?? null);
      const isHidden = state.hiddenDatasets.has(area.id);
      const isBar    = state.chartType === 'bar';

      return {
        label:           area.label,
        data,
        areaId:          area.id,
        borderColor:     area.color,
        backgroundColor: isBar ? area.color + 'cc' : area.color + '22',
        fill:            false,
        tension:         isBar ? 0 : 0.4,
        pointRadius:     labels.length > 60 ? 0 : 4,
        pointHoverRadius:6,
        borderWidth:     isBar ? 0 : 2.5,
        spanGaps:        true,
        hidden:          isHidden,
      };
    });
}

/* ── render / update chart ───────────────────────────────────── */
function renderChart() {
  const { labels, seriesMap } = getFilteredSeries();
  const canvas  = document.getElementById('mainChart');
  const wrapper = canvas.closest('.chart-wrapper');

  // remove previous empty state overlay if any
  wrapper.querySelectorAll('.chart-empty-state').forEach(el => el.remove());

  if (chartInstance) {
    chartInstance.destroy();
    chartInstance = null;
  }

  updateSubtitle(labels);

  if (!labels.length) {
    canvas.style.visibility = 'hidden';
    const noData = state.activeAreas.size === 0;
    const empty = document.createElement('div');
    empty.className = 'chart-empty-state';
    empty.innerHTML = `
      <svg viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
        <rect x="8" y="36" width="10" height="20" rx="2" opacity=".35"/>
        <rect x="22" y="24" width="10" height="32" rx="2" opacity=".25"/>
        <rect x="36" y="30" width="10" height="26" rx="2" opacity=".20"/>
        <rect x="50" y="18" width="6" height="38" rx="2" opacity=".15"/>
        <line x1="4" y1="58" x2="60" y2="58" opacity=".3"/>
        <line x1="32" y1="6" x2="32" y2="54" stroke-dasharray="3 3" opacity=".2"/>
        <circle cx="32" cy="14" r="6" opacity=".5"/>
        <line x1="29" y1="11" x2="35" y2="17" opacity=".7"/>
        <line x1="35" y1="11" x2="29" y2="17" opacity=".7"/>
      </svg>
      <p class="empty-title">${noData ? 'Nenhuma área selecionada' : 'Nenhum dado para o período'}</p>
      <p class="empty-desc">${noData
        ? 'Selecione pelo menos uma área no painel lateral para visualizar o gráfico.'
        : 'Não encontramos movimentações no intervalo de datas selecionado.<br>Tente ampliar o período ou escolher outras áreas.'
      }</p>`;
    wrapper.appendChild(empty);
    return;
  }

  canvas.style.visibility = '';
  const formattedLabels = labels.map(l => formatLabel(l, state.granularity));
  const datasets = buildChartDatasets(labels, seriesMap);

  const type = state.chartType === 'area' ? 'line' : state.chartType;

  const ctx = canvas.getContext('2d');

  chartInstance = new Chart(ctx, {
    type,
    data: { labels: formattedLabels, datasets },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#1e293b',
          titleColor: '#94a3b8',
          titleFont: { size: 12, weight: '700' },
          titleMarginBottom: 8,
          bodyColor: '#e2e8f0',
          bodyFont: { size: 12.5 },
          footerColor: '#94a3b8',
          footerFont: { size: 11, weight: '700' },
          footerMarginTop: 8,
          padding: { top: 12, bottom: 12, left: 16, right: 18 },
          cornerRadius: 12,
          boxPadding: 5,
          borderColor: 'rgba(255,255,255,0.08)',
          borderWidth: 1,
          itemSort: (a, b) => (Number.isFinite(b.parsed.y) ? b.parsed.y : 0) - (Number.isFinite(a.parsed.y) ? a.parsed.y : 0),
          filter: item => Number.isFinite(item.parsed.y),
          callbacks: {
            title: items => {
              if (!items.length) return '';
              const rawDate = labels[items[0].dataIndex];
              if (!rawDate) return items[0].label;
              const d = new Date(rawDate + 'T00:00:00');
              return state.granularity === 'monthly'
                ? d.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })
                    .replace(/^./, c => c.toUpperCase())
                : d.toLocaleDateString('pt-BR', { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' });
            },
            label: ctx => `  ${ctx.dataset.label}: ${fmt(ctx.parsed.y)}`,
            labelColor: ctx => ({
              borderColor: ctx.dataset.borderColor,
              backgroundColor: ctx.dataset.borderColor,
              borderWidth: 2,
              borderRadius: 3,
            }),
            footer: items => {
              if (items.length <= 1) return '';
              const total = items.reduce((s, i) => s + i.parsed.y, 0);
              return `Total: ${fmt(total)}`;
            },
          },
        },
        datalabels: state.showLabels ? {
          display: ctx => {
            // no gráfico de barras mostra em todos; em linha só se não estiver muito denso
            const total = ctx.chart.data.labels.length;
            if (total > 30) return false;
            return ctx.dataset.data[ctx.dataIndex] !== null;
          },
          formatter: v => fmtLabel(v ?? 0),
          color: ctx => ctx.dataset.borderColor,
          font: { size: 9.5, weight: '700', family: "'Segoe UI', system-ui, sans-serif" },
          anchor: state.chartType === 'bar' ? 'end' : 'top',
          align:  state.chartType === 'bar' ? 'top'  : 'top',
          offset: 3,
          backgroundColor: 'rgba(255,255,255,0.82)',
          borderRadius: 4,
          padding: { top: 2, bottom: 2, left: 4, right: 4 },
          clip: false,
        } : { display: false },
      },
      scales: {
        x: {
          grid: { color: '#f1f5f9', drawBorder: false },
          ticks: {
            color: '#64748b',
            font: { size: 11, weight: '600' },
            maxTicksLimit: state.granularity === 'daily' ? 15 : 14,
          },
        },
        y: {
          grid: { color: '#f1f5f9', drawBorder: false },
          ticks: {
            color: '#64748b',
            font: { size: 11, weight: '600' },
            callback: v => fmtLabel(v),
            maxTicksLimit: 8,
          },
          beginAtZero: true,
        },
      },
    },
  });
}

function updateSubtitle(labels) {
  const el = document.getElementById('chartSubtitle');
  if (!labels.length) { el.textContent = 'Sem dados no período'; return; }
  const from = formatLabel(labels[0], state.granularity);
  const to   = formatLabel(labels[labels.length - 1], state.granularity);
  const gran = state.granularity === 'daily' ? 'Visualização diária' : 'Visualização mensal';
  el.textContent = `${from} – ${to} · ${gran}`;
}

/* legenda substituída pelo painel lateral — sem função separada */

/* ── render KPIs ─────────────────────────────────────────────── */
function renderKPIs() {
  const { dateFrom, dateTo, granularity, activeAreas } = state;
  const row = document.getElementById('kpiRow');
  row.innerHTML = '';

  let grandTotal = 0;
  let grandPrev  = 0;

  const areaStats = DATASET.areas
    .filter(a => activeAreas.has(a.id))
    .map(area => {
      const values = (granularity === 'daily' ? area.dailyValues : area.monthlyValues)
        .filter(v => dateInRange(v.date, dateFrom, dateTo));
      const total = values.reduce((s, v) => s + v.value, 0);
      const prev  = calcPrevTotal(area, dateFrom, dateTo, granularity);
      grandTotal += total;
      if (prev !== null) grandPrev += prev;
      return { ...area, periodTotal: total, periodPrev: prev };
    });

  // Grand total card
  const grandDelta = grandPrev ? ((grandTotal - grandPrev) / grandPrev) * 100 : null;
  const totalCard = document.createElement('div');
  totalCard.className = 'kpi-card total-card';
  totalCard.innerHTML = `
    <div class="kpi-header">
      <div class="kpi-label-row">
        <span class="kpi-dot" style="background:var(--blue-main)"></span>
        <span class="kpi-label">Tot. Amortizado</span>
      </div>
    </div>
    <div class="kpi-value">${fmtShort(grandTotal)}</div>
    <div class="kpi-sub">Total Amortização</div>
  `;
  row.appendChild(totalCard);

  // Per-area cards
  areaStats.forEach(area => {
    const card = document.createElement('div');
    card.className = 'kpi-card';
    const iconSvg = AREA_ICONS[area.id] || '<circle cx="12" cy="12" r="9"/>';
    const delta   = area.periodPrev ? ((area.periodTotal - area.periodPrev) / area.periodPrev) * 100 : null;
    card.innerHTML = `
      <div class="kpi-header">
        <div class="kpi-label-row">
          <span class="kpi-dot" style="background:${area.color}"></span>
          <span class="kpi-label">${area.label}</span>
        </div>
      </div>
      <div class="kpi-value">${fmtShort(area.periodTotal)}</div>
      <div class="kpi-sub">Total Amortização</div>
    `;
    card.addEventListener('click', () => {
      if (state.activeAreas.size === 1 && state.activeAreas.has(area.id)) {
        state.activeAreas = new Set(DATASET.areas.map(a => a.id));
      } else {
        state.activeAreas = new Set([area.id]);
      }
      syncCheckboxes();
      refreshAll();
    });
    card.style.cursor = 'pointer';
    row.appendChild(card);
  });
}

/* ── sort headers ────────────────────────────────────────────── */
function updateSortHeaders() {
  const unit = state.granularity === 'daily' ? 'Dia' : 'Mês';

  const setup = (th, key, label) => {
    if (!th) return;
    const isActive = state.tableSortCol === key;
    const arrow = isActive
      ? `<span class="sort-icon active">${state.tableSortDir === 'asc' ? '↑' : '↓'}</span>`
      : `<span class="sort-icon">↓</span>`;
    th.innerHTML = `${label} ${arrow}`;
    th.onclick = () => {
      if (state.tableSortCol === key) {
        state.tableSortDir = state.tableSortDir === 'desc' ? 'asc' : 'desc';
      } else {
        state.tableSortCol = key;
        state.tableSortDir = 'desc';
      }
      renderTable();
    };
  };

  setup(document.querySelector('[data-sort="area"]'),  'area',  'Área');
  setup(document.querySelector('[data-sort="total"]'), 'total', 'Total Amortizado');
  setup(document.getElementById('th-avg'),             'avg',   `Média/${unit}`);
  setup(document.getElementById('th-max'),             'max',   `Maior ${unit}`);
  setup(document.getElementById('th-min'),             'min',   `Menor ${unit}`);
  setup(document.querySelector('[data-sort="pct"]'),   'pct',   'Percentual');
}

/* ── render table ────────────────────────────────────────────── */
function renderTable() {
  const { dateFrom, dateTo, granularity, activeAreas } = state;
  const body = document.getElementById('tableBody');
  const foot = document.getElementById('tableFoot');
  const periodLabel = document.getElementById('tablePeriodLabel');
  body.innerHTML = '';
  foot.innerHTML = '';

  const fromStr = dateFrom.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' });
  const toStr   = dateTo.toLocaleDateString('pt-BR',   { day: '2-digit', month: 'short', year: 'numeric' });
  periodLabel.innerHTML = `
    <span class="period-tag">De</span>
    <span class="period-seg">${fromStr}</span>
    <span class="period-tag">Até</span>
    <span class="period-seg">${toStr}</span>`;

  updateSortHeaders();

  let grandTotal = 0;
  let grandContracts = 0;
  const rows = [];

  DATASET.areas
    .filter(a => activeAreas.has(a.id))
    .forEach(area => {
      const values = (granularity === 'daily' ? area.dailyValues : area.monthlyValues)
        .filter(v => dateInRange(v.date, dateFrom, dateTo))
        .map(v => v.value);

      if (!values.length) return;
      const total  = values.reduce((s, v) => s + v, 0);
      const avg    = total / values.length;
      const max    = Math.max(...values);
      const min    = Math.min(...values);
      grandTotal += total;
      grandContracts += area.contracts;
      rows.push({ area, total, avg, max, min });
    });

  if (!rows.length) {
    const noAreas = state.activeAreas.size === 0;
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td colspan="6" class="table-empty-cell">
        <div class="empty-inner">
          <svg viewBox="0 0 24 24">
            <rect x="3" y="3" width="18" height="18" rx="2"/>
            <line x1="3" y1="9" x2="21" y2="9"/>
            <line x1="9" y1="21" x2="9" y2="9"/>
          </svg>
          <span class="empty-title">${noAreas ? 'Nenhuma área selecionada' : 'Nenhum dado para o período'}</span>
          <span class="empty-desc">${noAreas
            ? 'Selecione pelo menos uma área para visualizar os dados consolidados.'
            : 'Não há movimentações registradas no intervalo de datas selecionado.'
          }</span>
        </div>
      </td>`;
    body.appendChild(tr);
    return;
  }

  if (state.tableSortCol) {
    rows.sort((a, b) => {
      let va, vb;
      switch (state.tableSortCol) {
        case 'area':              va = a.area.label; vb = b.area.label; break;
        case 'total': case 'pct': va = a.total;      vb = b.total;      break;
        case 'avg':               va = a.avg;        vb = b.avg;        break;
        case 'max':               va = a.max;        vb = b.max;        break;
        case 'min':               va = a.min;        vb = b.min;        break;
        default: return 0;
      }
      if (typeof va === 'string')
        return state.tableSortDir === 'asc' ? va.localeCompare(vb, 'pt-BR') : vb.localeCompare(va, 'pt-BR');
      return state.tableSortDir === 'asc' ? va - vb : vb - va;
    });
  }

  rows.forEach(r => {
    const pct = grandTotal ? (r.total / grandTotal) * 100 : 0;
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>
        <span class="area-chip-neutral">
          <span class="area-dot" style="background:${r.area.color}"></span>
          ${r.area.label}
        </span>
      </td>
      <td>${fmt(r.total)}</td>
      <td>${fmtShort(r.avg)}</td>
      <td class="val-high">${fmtShort(r.max)}</td>
      <td class="val-low">${fmtShort(r.min)}</td>
      <td>
        <div class="bar-cell">
          <div class="mini-bar">
            <div class="mini-bar-fill" style="width:${pct}%;background:${r.area.color}"></div>
          </div>
          <span class="pct-label">${pct.toFixed(1)}%</span>
        </div>
      </td>`;
    body.appendChild(tr);
  });

  // Footer total
  const tfr = document.createElement('tr');
  tfr.innerHTML = `
    <td>Total Geral</td>
    <td colspan="5">${fmt(grandTotal)}</td>`;
  foot.appendChild(tfr);
}

/* ── table sort init ─────────────────────────────────────────── */
function initTableSort() { /* onclick atribuído em updateSortHeaders */ }

/* ── area checkboxes ─────────────────────────────────────────── */
function renderAreaChecks() {
  const container = document.getElementById('areaChecks');
  container.innerHTML = '';

  // compute period totals for badge
  const { dateFrom, dateTo, granularity } = state;
  const totals = {};
  DATASET.areas.forEach(area => {
    const vals = (granularity === 'daily' ? area.dailyValues : area.monthlyValues)
      .filter(v => dateInRange(v.date, dateFrom, dateTo));
    totals[area.id] = vals.reduce((s, v) => s + v.value, 0);
  });

  DATASET.areas.forEach(area => {
    const checked = state.activeAreas.has(area.id);
    const label = document.createElement('label');
    label.className = 'area-check-item' + (checked ? ' checked' : '');
    if (checked) {
      label.style.borderColor = 'var(--blue-main)';
      label.style.boxShadow   = 'inset 0 -3px 0 var(--blue-main)';
    }
    label.innerHTML = `
      <input type="checkbox" value="${area.id}" ${checked ? 'checked' : ''} />
      <span class="cb-box" style="${checked ? 'background:var(--blue-main);border-color:var(--blue-main)' : ''}">
        <svg viewBox="0 0 12 12"><polyline points="2,6 5,9 10,3"/></svg>
      </span>
      <span class="cb-label" style="color:${checked ? area.color : 'var(--gray-500)'}">${area.label}</span>`;
    label.addEventListener('change', e => {
      if (e.target.checked) state.activeAreas.add(area.id);
      else state.activeAreas.delete(area.id);
      state.hiddenDatasets.clear();
      syncCheckboxes();
      refreshAll();
    });
    container.appendChild(label);
  });
}

function syncCheckboxes() {
  document.querySelectorAll('.area-check-item').forEach(label => {
    const cb   = label.querySelector('input[type="checkbox"]');
    const box  = label.querySelector('.cb-box');
    const id   = cb.value;
    const area = DATASET.areas.find(a => a.id === id);
    const on   = state.activeAreas.has(id);
    cb.checked = on;
    if (on) {
      label.classList.add('checked');
      label.style.borderColor = 'var(--blue-main)';
      label.style.boxShadow   = 'inset 0 -3px 0 var(--blue-main)';
      box.style.background    = 'var(--blue-main)';
      box.style.borderColor   = 'var(--blue-main)';
      const lbl = label.querySelector('.cb-label');
      if (lbl) lbl.style.color = area.color;
    } else {
      label.classList.remove('checked');
      label.style.borderColor = '';
      label.style.boxShadow   = '';
      box.style.background    = '';
      box.style.borderColor   = '';
      const lbl = label.querySelector('.cb-label');
      if (lbl) lbl.style.color = 'var(--gray-500)';
    }
  });
}

/* ── preset period buttons ───────────────────────────────────── */
function setPreset(days, months, years) {
  const to = new Date();
  to.setHours(23, 59, 59, 999);
  const from = new Date(to);
  if (days)   from.setDate(from.getDate() - days + 1);
  if (months) from.setMonth(from.getMonth() - months);
  if (years)  from.setFullYear(from.getFullYear() - years);
  from.setHours(0, 0, 0, 0);
  state.dateFrom    = from;
  state.dateTo      = to;
  state.granularity = detectGranularity(from, to);
  document.getElementById('dateFrom').value = from.toISOString().slice(0, 10);
  document.getElementById('dateTo').value   = to.toISOString().slice(0, 10);
}

document.querySelectorAll('.btn-preset').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.btn-preset').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const p = btn.dataset.preset;
    if (p === '7d')  setPreset(7);
    if (p === '30d') setPreset(30);
    if (p === '3m')  setPreset(null, 3);
    if (p === '6m')  setPreset(null, 6);
    if (p === '1a')  setPreset(null, null, 1);
    state.hiddenDatasets.clear();
    refreshAll();
  });
});

function shiftPeriod(direction) {
  const span = state.dateTo - state.dateFrom;
  const shift = direction * (span + 86_400_000);
  const newFrom = new Date(state.dateFrom.getTime() + shift);
  const newTo   = new Date(state.dateTo.getTime()   + shift);
  newFrom.setHours(0, 0, 0, 0);
  newTo.setHours(23, 59, 59, 999);
  state.dateFrom = newFrom;
  state.dateTo   = newTo;
  state.granularity = detectGranularity(newFrom, newTo);
  document.getElementById('dateFrom').value = newFrom.toISOString().slice(0, 10);
  document.getElementById('dateTo').value   = newTo.toISOString().slice(0, 10);
  document.querySelectorAll('.btn-preset').forEach(b => b.classList.remove('active'));
  refreshAll();
}

/* btnPrevPeriod e btnNextPeriod removidos do layout */

/* ── toggle data labels ──────────────────────────────────────── */
document.getElementById('toggleLabels').addEventListener('change', e => {
  state.showLabels = e.target.checked;
  renderChart();
});

/* ── toggle all areas ────────────────────────────────────────── */
document.getElementById('btnToggleAll').addEventListener('click', () => {
  const allOn = state.activeAreas.size === DATASET.areas.length;
  if (allOn) {
    state.activeAreas.clear();
  } else {
    DATASET.areas.forEach(a => state.activeAreas.add(a.id));
  }
  state.hiddenDatasets.clear();
  document.getElementById('btnToggleAll').textContent =
    state.activeAreas.size === DATASET.areas.length ? 'Limpar' : 'Todos';
  syncCheckboxes();
  refreshAll();
});

/* ── date filter ─────────────────────────────────────────────── */
document.getElementById('btnApplyFilter').addEventListener('click', applyDateFilter);
document.getElementById('dateFrom').addEventListener('change', () => {});
document.getElementById('dateTo').addEventListener('change', () => {});

function applyDateFilter() {
  const fromVal = document.getElementById('dateFrom').value;
  const toVal   = document.getElementById('dateTo').value;
  if (!fromVal || !toVal) return;
  state.dateFrom = new Date(fromVal + 'T00:00:00');
  state.dateTo   = new Date(toVal   + 'T23:59:59');
  state.granularity = detectGranularity(state.dateFrom, state.dateTo);
  state.hiddenDatasets.clear();
  refreshAll();
}

document.getElementById('btnReset').addEventListener('click', () => {
  document.getElementById('dateFrom').value = '2025-06-01';
  document.getElementById('dateTo').value   = '2026-06-30';
  state.dateFrom    = new Date('2025-06-01T00:00:00');
  state.dateTo      = new Date('2026-06-30T23:59:59');
  state.granularity = 'monthly';
  state.activeAreas = new Set(DATASET.areas.map(a => a.id));
  state.hiddenDatasets.clear();
  document.getElementById('btnToggleAll').textContent = 'Limpar';
  syncCheckboxes();
  refreshAll();
});

/* ── chart type toggle ───────────────────────────────────────── */
document.querySelectorAll('.chart-type-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.chart-type-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    state.chartType = btn.dataset.type;
    renderChart();
  });
});

/* ── export chart as PNG ─────────────────────────────────────── */
document.getElementById('btnExport').addEventListener('click', () => {
  if (!chartInstance) return;
  const link = document.createElement('a');
  link.download = `amortizacao-relatorio-${new Date().toISOString().slice(0,10)}.png`;
  link.href = chartInstance.toBase64Image('image/png', 1.0);
  link.click();
});

/* ── full refresh ────────────────────────────────────────────── */
function refreshAll() {
  renderKPIs();
  renderAreaChecks();
  renderChart();
  renderTable();
  const btn = document.getElementById('btnToggleAll');
  btn.textContent = state.activeAreas.size === DATASET.areas.length
    ? 'Limpar'
    : 'Todos';
}

/* ── init ────────────────────────────────────────────────────── */
function init() {
  initTableSort();
  refreshAll();
}

init();

/* placeholder removed */
function _insightSVG_removed() {
  const p = {
    trophy:       '<path d="M6 9H4a2 2 0 000 4h2M18 9h2a2 2 0 010 4h-2M6 9V5l6 2 6-2v4c0 3.31-2.69 6-6 6S6 12.31 6 9z"/><line x1="12" y1="17" x2="12" y2="21"/><line x1="8" y1="21" x2="16" y2="21"/>',
    'trend-up':   '<polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/>',
    'trend-down': '<polyline points="23 18 13.5 8.5 8.5 13.5 1 6"/><polyline points="17 18 23 18 23 12"/>',
    calendar:     '<rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
    pie:          '<path d="M21.21 15.89A10 10 0 118 2.83"/><path d="M22 12A10 10 0 0012 2v10z"/>',
    zap:          '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',
    'bar-chart':  '<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>',
  };
  return `<svg viewBox="0 0 24 24">${p[type] || p.zap}</svg>`;
}

/* ── gera lista de insights a partir dos dados filtrados ── */
function generateInsights(areaStats, grandTotal, labels) {
  const insights = [];
  const sorted   = [...areaStats].sort((a, b) => b.total - a.total);

  /* 1 — Área líder */
  const leader    = sorted[0];
  const leaderPct = ((leader.total / grandTotal) * 100).toFixed(1);
  insights.push({
    icon:  'trophy',
    color: leader.area.color,
    label: 'Área Líder',
    value: leader.area.label,
    desc:  `Concentrou ${leaderPct}% do total — ${fmtShort(leader.total)} desembolsados no período.`,
  });

  /* 2 — Tendência: média do 1º terço vs último terço das datas */
  if (labels.length >= 3) {
    const byDate = {};
    areaStats.forEach(s => s.values.forEach(v => { byDate[v.date] = (byDate[v.date] || 0) + v.value; }));
    const dates  = [...labels].sort();
    const third  = Math.max(1, Math.ceil(dates.length / 3));
    const avgIni = dates.slice(0, third).reduce((s, d) => s + (byDate[d] || 0), 0) / third;
    const avgFim = dates.slice(-third).reduce((s, d) => s + (byDate[d] || 0), 0) / third;
    const growth = ((avgFim - avgIni) / avgIni) * 100;
    const up     = growth >= 0;
    insights.push({
      icon:  up ? 'trend-up' : 'trend-down',
      color: up ? '#16a34a' : '#dc2626',
      label: 'Tendência',
      value: `${up ? '+' : ''}${growth.toFixed(1)}%`,
      desc:  `Comparando início e fim do período, há ${up ? 'crescimento' : 'queda'} no volume médio ${state.granularity === 'monthly' ? 'mensal' : 'diário'}.`,
    });
  }

  /* 3 — Pico de amortização */
  const byDate    = {};
  areaStats.forEach(s => s.values.forEach(v => { byDate[v.date] = (byDate[v.date] || 0) + v.value; }));
  const peakEntry = Object.entries(byDate).reduce((mx, e) => e[1] > mx[1] ? e : mx, ['', 0]);
  if (peakEntry[0]) {
    const d      = new Date(peakEntry[0] + 'T00:00:00');
    const mthly  = state.granularity === 'monthly';
    const dlabel = d.toLocaleDateString('pt-BR', mthly
      ? { month: 'long', year: 'numeric' }
      : { day: '2-digit', month: 'short', year: 'numeric' });
    insights.push({
      icon:  'calendar',
      color: '#d97706',
      label: 'Pico de Amortização',
      value: fmtShort(peakEntry[1]),
      desc:  `Maior volume registrado em ${dlabel} — ${((peakEntry[1] / grandTotal) * 100).toFixed(1)}% do total do período.`,
    });
  }

  /* 4 — Concentração top-2 (ou contratos se área única) */
  if (sorted.length >= 2) {
    const top2pct = (((sorted[0].total + sorted[1].total) / grandTotal) * 100).toFixed(1);
    insights.push({
      icon:  'pie',
      color: '#6366f1',
      label: 'Concentração',
      value: `${top2pct}%`,
      desc:  `${sorted[0].area.label} e ${sorted[1].area.label} respondem juntas por ${top2pct}% do total desembolsado.`,
    });
  } else {
    insights.push({
      icon:  'bar-chart',
      color: '#6366f1',
      label: 'Contratos Ativos',
      value: sorted[0].area.contracts.toLocaleString('pt-BR'),
      desc:  `${sorted[0].area.label} possui ${sorted[0].area.contracts} contratos em carteira no período analisado.`,
    });
  }

  return insights;
}

/* ── helper: uma linha do poster ── */
function posterRow(flip, color, numHtml, numSub, iconSvg, descHtml) {
  const statSide = `
    <div class="poster-stat-side">
      <div class="poster-big-num" style="color:${color}">${numHtml}</div>
      <div class="poster-num-sublabel">${numSub}</div>
    </div>`;
  const iconSide = `
    <div class="poster-icon-side">
      <div class="poster-icon-box" style="background:${color}20;color:${color}">${iconSvg}</div>
      <div class="poster-desc">${descHtml}</div>
    </div>`;
  return `
    <div class="poster-row${flip ? ' flip' : ''}">
      ${flip ? iconSide + statSide : statSide + iconSide}
    </div>`;
}

/* ── SVGs para o poster ── */
const POSTER_ICONS = {
  total:     `<svg viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg>`,
  leader:    `<svg viewBox="0 0 24 24"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>`,
  trend_up:  `<svg viewBox="0 0 24 24"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>`,
  trend_dn:  `<svg viewBox="0 0 24 24"><polyline points="23 18 13.5 8.5 8.5 13.5 1 6"/><polyline points="17 18 23 18 23 12"/></svg>`,
  peak:      `<svg viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`,
  conc:      `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4l3 3"/></svg>`,
  avg:       `<svg viewBox="0 0 24 24"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>`,
  contracts: `<svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>`,
};

/* ── monta o HTML interno do dialog (dark poster v3) ── */
function buildInfographicHTML(areaStats, grandTotal, insights, labels) {
  const sorted         = [...areaStats].sort((a, b) => b.total - a.total);
  const fromStr        = state.dateFrom.toLocaleDateString('pt-BR', { month: 'short', year: 'numeric' });
  const toStr          = state.dateTo.toLocaleDateString('pt-BR',   { month: 'short', year: 'numeric' });
  const now            = new Date().toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });
  const totalContracts = areaStats.reduce((s, a) => s + a.area.contracts, 0);
  const granLabel      = state.granularity === 'monthly' ? 'meses' : 'dias';
  const avgPer         = labels.length ? grandTotal / labels.length : 0;
  const leader         = sorted[0];
  const leaderPct      = grandTotal && leader ? (leader.total / grandTotal * 100) : 0;
  const top2pct        = sorted.slice(0, 2).reduce((s, a) => s + (grandTotal ? a.total / grandTotal * 100 : 0), 0);

  /* pico */
  let peakVal = 0, peakLabel = '';
  areaStats.forEach(s => {
    s.values.forEach(v => {
      if (v.value > peakVal) { peakVal = v.value; peakLabel = formatLabel(v.date, state.granularity); }
    });
  });

  /* tendência (compara 1º vs último terço do período) */
  let trendPct = 0;
  if (labels.length >= 3) {
    const third = Math.max(1, Math.floor(labels.length / 3));
    const firstDates = labels.slice(0, third);
    const lastDates  = labels.slice(-third);
    const sumPeriod = (dates) => areaStats.reduce((s, a) => {
      const map = Object.fromEntries(a.values.map(v => [v.date, v.value]));
      return s + dates.reduce((ss, d) => ss + (map[d] || 0), 0);
    }, 0);
    const first = sumPeriod(firstDates);
    const last  = sumPeriod(lastDates);
    trendPct = first ? ((last - first) / first) * 100 : 0;
  }
  const trendUp    = trendPct >= 0;
  const trendColor = trendUp ? '#2dd4bf' : '#f87171';

  const SEP = `<hr class="poster-sep">`;

  const rows = [
    posterRow(false, '#4ade80',
      fmtShort(grandTotal), 'Total Desembolsado',
      POSTER_ICONS.total,
      `Soma de todas as amortizações das <strong>${areaStats.length} áreas</strong> no período analisado.`
    ),
    SEP,
    posterRow(true, '#fb923c',
      `${leaderPct.toFixed(0)}%`, 'Área Líder',
      POSTER_ICONS.leader,
      `<strong>${leader ? leader.area.label : '—'}</strong> concentra mais amortização: ${fmtShort(leader ? leader.total : 0)}.`
    ),
    SEP,
    posterRow(false, trendColor,
      `${trendPct >= 0 ? '+' : ''}${trendPct.toFixed(1)}%`, 'Tendência',
      trendUp ? POSTER_ICONS.trend_up : POSTER_ICONS.trend_dn,
      `Variação entre o início e o fim do período — evolução <strong>${trendUp ? 'positiva' : 'negativa'}</strong>.`
    ),
    SEP,
    posterRow(true, '#fbbf24',
      fmtShort(peakVal), 'Maior Mês',
      POSTER_ICONS.peak,
      `Pico de amortização registrado em <strong>${peakLabel}</strong> em todo o período.`
    ),
    SEP,
    posterRow(false, '#c084fc',
      `${top2pct.toFixed(0)}%`, 'Concentração',
      POSTER_ICONS.conc,
      `As <strong>2 principais áreas</strong> respondem por ${top2pct.toFixed(1)}% do total desembolsado.`
    ),
    SEP,
    posterRow(true, '#f472b6',
      fmtShort(avgPer), `Média por ${state.granularity === 'monthly' ? 'Mês' : 'Dia'}`,
      POSTER_ICONS.avg,
      `Amortização média em cada ${state.granularity === 'monthly' ? 'mês' : 'dia'} dos <strong>${labels.length} ${granLabel}</strong> analisados.`
    ),
    SEP,
    posterRow(false, '#38bdf8',
      totalContracts.toLocaleString('pt-BR'), 'Contratos',
      POSTER_ICONS.contracts,
      `Total de contratos ativos nas <strong>${areaStats.length} áreas</strong> do período selecionado.`
    ),
  ].join('');

  return `
    <div class="info-header">
      <div class="info-header-left">
        <div class="info-brand-chip">CEFGA</div>
        <div>
          <h2 class="info-title">Relatórios de Amortização</h2>
          <p class="info-period-text">${fromStr} – ${toStr} · ${areaStats.length} área${areaStats.length !== 1 ? 's' : ''}</p>
        </div>
      </div>
      <button class="info-close-btn" id="infoCloseBtn" type="button" aria-label="Fechar">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
          <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
        </svg>
      </button>
    </div>

    <div class="infoposter">
      <div class="poster-title-block">
        <div class="poster-eyebrow">Análise de Amortização · CEFGA</div>
        <div class="poster-main-title">EM <span>NÚMEROS</span></div>
        <div class="poster-em-numbers">${fromStr.toUpperCase()} — ${toStr.toUpperCase()}</div>
        <div class="poster-period-tag">${labels.length} ${granLabel} · ${areaStats.length} áreas · ${totalContracts.toLocaleString('pt-BR')} contratos</div>
      </div>

      ${rows}

      <div class="poster-footer-bar">
        <span class="poster-footer-text">Gerado em ${now}</span>
        <button class="poster-print-btn" id="infoExportBtn" type="button">
          <svg viewBox="0 0 24 24"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
          Imprimir
        </button>
      </div>
    </div>`;
}

/* ── renderiza donut dentro do dialog ── */
function renderInfoDonut(areaStats, grandTotal) {
  if (infoDonutInstance) { infoDonutInstance.destroy(); infoDonutInstance = null; }
  const canvas = document.getElementById('infoDonut');
  if (!canvas) return;
  const sorted = [...areaStats].sort((a, b) => b.total - a.total);
  infoDonutInstance = new Chart(canvas, {
    type: 'doughnut',
    data: {
      labels: sorted.map(s => s.area.label),
      datasets: [{
        data:            sorted.map(s => s.total),
        backgroundColor: sorted.map(s => s.area.color),
        borderWidth:     3,
        borderColor:     '#fff',
        hoverOffset:     8,
      }],
    },
    options: {
      responsive:          false,
      maintainAspectRatio: false,
      cutout:              '68%',
      plugins: {
        legend:     { display: false },
        tooltip:    {
          backgroundColor: '#1e293b',
          callbacks: {
            label: ctx => ` ${ctx.label}: ${((ctx.parsed / grandTotal) * 100).toFixed(1)}% — ${fmt(ctx.parsed)}`,
          },
        },
        datalabels: { display: false },
      },
    },
  });
}

/* ── renderiza mini gráfico de linhas dentro do dialog ── */
function renderInfoMiniChart(areaStats, labels) {
  if (infoMiniInstance) { infoMiniInstance.destroy(); infoMiniInstance = null; }
  const canvas = document.getElementById('infoMiniChart');
  if (!canvas) return;

  const fmtLabels = labels.map(l => formatLabel(l, state.granularity));
  const datasets  = areaStats.map(s => {
    const map = Object.fromEntries(s.values.map(v => [v.date, v.value]));
    return {
      label:           s.area.label,
      data:            labels.map(l => map[l] ?? null),
      borderColor:     s.area.color,
      backgroundColor: s.area.color + '18',
      fill:            false,
      tension:         0.4,
      borderWidth:     2,
      pointRadius:     labels.length > 60 ? 0 : 3,
      pointHoverRadius:5,
    };
  });

  infoMiniInstance = new Chart(canvas, {
    type: 'line',
    data: { labels: fmtLabels, datasets },
    options: {
      responsive:          true,
      maintainAspectRatio: false,
      interaction:         { mode: 'index', intersect: false },
      plugins: {
        legend:     { display: false },
        tooltip:    {
          backgroundColor: '#1e293b',
          callbacks: { label: c => ` ${c.dataset.label}: ${fmtShort(c.parsed.y ?? 0)}` },
        },
        datalabels: { display: false },
      },
      scales: {
        x: { grid: { color: '#f1f5f9' }, ticks: { color: '#94a3b8', font: { size: 10 }, maxTicksLimit: 13 } },
        y: { grid: { color: '#f1f5f9' }, ticks: { color: '#94a3b8', font: { size: 10 }, callback: v => fmtShort(v) }, beginAtZero: true },
      },
    },
  });
}

/* ── abre o dialog ── */
function openInfographic() {
  const { dateFrom, dateTo, granularity, activeAreas } = state;

  const areaStats = DATASET.areas
    .filter(a => activeAreas.has(a.id))
    .map(area => {
      const values = (granularity === 'daily' ? area.dailyValues : area.monthlyValues)
        .filter(v => dateInRange(v.date, dateFrom, dateTo));
      const total = values.reduce((s, v) => s + v.value, 0);
      return { area, total, values };
    })
    .filter(s => s.total > 0);

  if (!areaStats.length) return;

  const grandTotal    = areaStats.reduce((s, a) => s + a.total, 0);
  const { labels }    = getFilteredSeries();
  const insights      = generateInsights(areaStats, grandTotal, labels);

  const panel = document.getElementById('infographicPanel');
  panel.innerHTML = buildInfographicHTML(areaStats, grandTotal, insights, labels);

  document.getElementById('infographicOverlay').classList.add('open');
  document.body.style.overflow = 'hidden';

  requestAnimationFrame(() => {
    document.getElementById('infoCloseBtn').addEventListener('click', closeInfographic);
    document.getElementById('infoExportBtn').addEventListener('click', () => window.print());
  });
}

/* ── fecha o dialog ── */
function closeInfographic() {
  document.getElementById('infographicOverlay').classList.remove('open');
  document.body.style.overflow = '';
  if (infoDonutInstance) { infoDonutInstance.destroy(); infoDonutInstance = null; }
  if (infoMiniInstance)  { infoMiniInstance.destroy();  infoMiniInstance  = null; }
}

document.getElementById('btnInsight').addEventListener('click', openInfographic);

document.getElementById('infographicOverlay').addEventListener('click', e => {
  if (e.target === e.currentTarget) closeInfographic();
});

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeInfographic();
});
