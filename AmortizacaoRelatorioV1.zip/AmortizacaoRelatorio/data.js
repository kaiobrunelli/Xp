/**
 * Mock dataset — Amortização Caixa
 *
 * Estrutura compatível com API real:
 * {
 *   meta: { totals: {...} },
 *   areas: [ { id, label, color, contracts, monthlyValues: [{date, value}] } ]
 * }
 *
 * "date" usa ISO YYYY-MM-DD do primeiro dia do mês para dados mensais,
 * ou YYYY-MM-DD exato para dados diários.
 */

/* Paleta CAIXA — tons 70 (originais) de cada família cromática */
const AREA_COLORS = {
  saneamento:    '#2072BE',   // Azul 60
  habitacao:     '#D49400',   // Tangerina 60
  infraestrutura:'#0099C5',   // Céu 60
  saude:         '#D4573E',   // Goiaba 60
  promoradia:    '#955C80',   // Uva 60
  protransporte: '#8FA808',   // Limão 60
};

const AREA_LABELS = {
  saneamento:    'Saneamento',
  habitacao:     'Habitação',
  infraestrutura:'Infraestrutura',
  saude:         'Saúde',
  promoradia:    'Pro-Moradia',
  protransporte: 'Pro-Transporte',
};

/* ── monthly seed data (Jun/2025 → Jun/2026) ─────────────────── */
function buildMonthlyValues(baseValues) {
  const start = new Date(2025, 5, 1); // June 2025
  return baseValues.map((value, i) => {
    const d = new Date(start);
    d.setMonth(start.getMonth() + i);
    return {
      date: d.toISOString().slice(0, 10),
      value,
    };
  });
}

/* ── daily data generator (interpolates + adds noise) ────────── */
function buildDailyValues(monthlyValues) {
  const daily = [];
  for (let mi = 0; mi < monthlyValues.length; mi++) {
    const mv = monthlyValues[mi];
    const [y, m] = mv.date.split('-').map(Number);
    const daysInMonth = new Date(y, m, 0).getDate();
    const dailyBase = mv.value / daysInMonth;
    for (let d = 1; d <= daysInMonth; d++) {
      const noise = 0.6 + Math.random() * 0.8;
      daily.push({
        date: `${y}-${String(m).padStart(2,'0')}-${String(d).padStart(2,'0')}`,
        value: Math.round(dailyBase * noise),
      });
    }
  }
  return daily;
}

/* ── raw monthly amounts per area (13 months) ────────────────── */
const RAW = {
  saneamento:    [4_820_000, 5_100_000, 4_960_000, 5_340_000, 5_080_000, 5_600_000, 5_420_000, 5_780_000, 6_100_000, 5_950_000, 6_280_000, 6_050_000, 6_420_000],
  habitacao:     [3_150_000, 3_280_000, 3_420_000, 3_190_000, 3_560_000, 3_780_000, 3_640_000, 3_900_000, 4_050_000, 3_870_000, 4_120_000, 3_990_000, 4_300_000],
  infraestrutura:[2_400_000, 2_550_000, 2_480_000, 2_700_000, 2_620_000, 2_870_000, 2_750_000, 2_990_000, 3_180_000, 3_050_000, 3_240_000, 3_100_000, 3_380_000],
  saude:         [1_230_000, 1_180_000, 1_290_000, 1_350_000, 1_420_000, 1_380_000, 1_460_000, 1_510_000, 1_480_000, 1_550_000, 1_600_000, 1_570_000, 1_640_000],
  promoradia:    [  980_000, 1_020_000,   960_000, 1_050_000, 1_110_000, 1_080_000, 1_140_000, 1_190_000, 1_160_000, 1_230_000, 1_270_000, 1_240_000, 1_310_000],
  protransporte: [  720_000,   760_000,   740_000,   810_000,   780_000,   850_000,   830_000,   890_000,   950_000,   920_000,   980_000,   960_000, 1_020_000],
};

/* ── contracts per area ───────────────────────────────────────── */
const CONTRACTS = {
  saneamento:    412,
  habitacao:     298,
  infraestrutura:187,
  saude:         143,
  promoradia:    98,
  protransporte: 61,
};

/* ── assemble dataset ─────────────────────────────────────────── */
function buildDataset() {
  const areas = Object.keys(RAW).map(id => {
    const monthly = buildMonthlyValues(RAW[id]);
    const daily   = buildDailyValues(monthly);
    const total   = monthly.reduce((s, m) => s + m.value, 0);
    return {
      id,
      label:     AREA_LABELS[id],
      color:     AREA_COLORS[id],
      contracts: CONTRACTS[id],
      total,
      monthlyValues: monthly,
      dailyValues:   daily,
    };
  });

  const grandTotal  = areas.reduce((s, a) => s + a.total, 0);
  const grandContracts = areas.reduce((s, a) => s + a.contracts, 0);

  return {
    meta: {
      generatedAt: new Date().toISOString(),
      currency: 'BRL',
      totals: {
        value:     grandTotal,
        contracts: grandContracts,
        periods:   13,
      },
    },
    areas,
  };
}

const DATASET = buildDataset();
