using System.ComponentModel;
using Microsoft.AspNetCore.Mvc;
using SipubDesembolsos.Server.Servicos;
using SipubDesembolsos.Shared;

namespace SipubDesembolsos.Server.Controllers;

[ApiController]
[Route("api/notificacao")]
[Produces("application/json")]
public class ControladorNotificacao : ControllerBase
{
    private readonly ServicoNotificacao _servico;

    public ControladorNotificacao(ServicoNotificacao servico) => _servico = servico;

    // ──────────────────────────────────────────────────────────────────────────
    // ENVIO GENÉRICO
    // ──────────────────────────────────────────────────────────────────────────

    /// <summary>Envia notificação geral (todos os usuários).</summary>
    [HttpPost("enviar-geral")]
    [ProducesResponseType(200)]
    public async Task<IActionResult> EnviarGeral([FromBody] RequisicaoEnvio req)
    {
        await _servico.EnviarGeralAsync(req.Titulo, req.Descricao, req.Tipo, dias: req.Dias, horas: req.Horas);
        return Ok(new { sucesso = true, escopo = "Geral", mensagem = "Notificação geral enviada e salva." });
    }

    /// <summary>Envia notificação apenas para um usuário específico.</summary>
    [HttpPost("enviar-individual/{usuarioId}")]
    [ProducesResponseType(200)]
    public async Task<IActionResult> EnviarIndividual(string usuarioId, [FromBody] RequisicaoEnvio req)
    {
        await _servico.EnviarIndividualAsync(req.Titulo, req.Descricao, req.Tipo, usuarioId, dias: req.Dias, horas: req.Horas);
        return Ok(new { sucesso = true, escopo = "Individual", destinatario = usuarioId, mensagem = $"Notificação enviada para '{usuarioId}'." });
    }

    // ──────────────────────────────────────────────────────────────────────────
    // CONSULTAS
    // ──────────────────────────────────────────────────────────────────────────

    /// <summary>Retorna as notificações do usuário (gerais + individuais), com estado de leitura.</summary>
    [HttpGet("minhas")]
    [ProducesResponseType(typeof(List<NotificacaoDto>), 200)]
    public async Task<IActionResult> ObterMinhas([FromQuery] string usuarioId)
    {
        if (string.IsNullOrWhiteSpace(usuarioId))
            return BadRequest("usuarioId é obrigatório.");

        var lista = await _servico.ObterMinhasAsync(usuarioId);
        return Ok(lista);
    }

    /// <summary>Retorna a contagem de notificações não lidas (para o badge do sino).</summary>
    [HttpGet("nao-lidas/total")]
    [ProducesResponseType(typeof(int), 200)]
    public async Task<IActionResult> ContarNaoLidas([FromQuery] string usuarioId)
    {
        if (string.IsNullOrWhiteSpace(usuarioId))
            return BadRequest("usuarioId é obrigatório.");

        var total = await _servico.ContarNaoLidasAsync(usuarioId);
        return Ok(total);
    }

    // ──────────────────────────────────────────────────────────────────────────
    // MARCAR COMO LIDA
    // ──────────────────────────────────────────────────────────────────────────

    /// <summary>Marca uma notificação específica como lida.</summary>
    [HttpPut("{id:int}/lida")]
    [ProducesResponseType(200)]
    public async Task<IActionResult> MarcarLida(int id, [FromQuery] string usuarioId)
    {
        if (string.IsNullOrWhiteSpace(usuarioId))
            return BadRequest("usuarioId é obrigatório.");

        var ok = await _servico.MarcarLidaAsync(id, usuarioId);
        return ok ? Ok(new { sucesso = true }) : NotFound();
    }

    /// <summary>Marca todas as notificações do usuário como lidas.</summary>
    [HttpPut("marcar-todas-lidas")]
    [ProducesResponseType(200)]
    public async Task<IActionResult> MarcarTodasLidas([FromQuery] string usuarioId)
    {
        if (string.IsNullOrWhiteSpace(usuarioId))
            return BadRequest("usuarioId é obrigatório.");

        await _servico.MarcarTodasLidasAsync(usuarioId);
        return Ok(new { sucesso = true, mensagem = "Todas marcadas como lidas." });
    }

    // ──────────────────────────────────────────────────────────────────────────
    // TESTES — GERAIS (sistema todo)
    // ──────────────────────────────────────────────────────────────────────────

    /// <summary>Simula aprovação de desembolso → notificação GERAL para todos.</summary>
    [HttpPost("teste/geral/desembolso-aprovado")]
    public async Task<IActionResult> TesteGeralDesembolsoAprovado([FromQuery] int? dias = null, [FromQuery] int? horas = null)
    {
        await _servico.EnviarGeralAsync("Desembolso aprovado ✓", "O desembolso DSB-001 — Prefeitura de Caruaru foi aprovado e liberado para pagamento.", "sucesso", dias: dias, horas: horas);
        return Ok(new { sucesso = true, escopo = "Geral" });
    }

    /// <summary>Simula pendência crítica → notificação GERAL para todos.</summary>
    [HttpPost("teste/geral/pendencia-critica")]
    public async Task<IActionResult> TesteGeralPendenciaCritica([FromQuery] int? dias = null, [FromQuery] int? horas = null)
    {
        await _servico.EnviarGeralAsync("Pendência crítica identificada", "O contrato DSB-004 — Feira de Santana possui 7 validações inválidas. Ação imediata necessária.", "alerta", dias: dias, horas: horas);
        return Ok(new { sucesso = true, escopo = "Geral" });
    }

    /// <summary>Simula prazo vencendo → notificação GERAL para todos.</summary>
    [HttpPost("teste/geral/prazo-vencendo")]
    public async Task<IActionResult> TesteGeralPrazoVencendo([FromQuery] int? dias = null, [FromQuery] int? horas = null)
    {
        await _servico.EnviarGeralAsync("Prazo vencendo em 2 dias", "O contrato DSB-004 — Município de Feira de Santana vence em 10/06/2025. Regularize a documentação.", "alerta", dias: dias, horas: horas);
        return Ok(new { sucesso = true, escopo = "Geral" });
    }

    /// <summary>Simula macro concluída → notificação GERAL para todos.</summary>
    [HttpPost("teste/geral/macro-concluida")]
    public async Task<IActionResult> TesteGeralMacroConcluida([FromQuery] int? dias = null, [FromQuery] int? horas = null)
    {
        await _servico.EnviarGeralAsync("Macro concluída", "O processamento automático finalizou: 6 contratos analisados, 43 validações executadas.", "sucesso", dias: dias, horas: horas);
        return Ok(new { sucesso = true, escopo = "Geral" });
    }

    /// <summary>Simula novo contrato → notificação GERAL para todos.</summary>
    [HttpPost("teste/geral/novo-contrato")]
    public async Task<IActionResult> TesteGeralNovoContrato([FromQuery] int? dias = null, [FromQuery] int? horas = null)
    {
        await _servico.EnviarGeralAsync("Novo contrato cadastrado", "O contrato DSB-007 — Prefeitura de Natal foi incluído na fila de análise.", "informacao", dias: dias, horas: horas);
        return Ok(new { sucesso = true, escopo = "Geral" });
    }

    /// <summary>Simula erro de sistema → notificação GERAL para todos.</summary>
    [HttpPost("teste/geral/erro-sistema")]
    public async Task<IActionResult> TesteGeralErroSistema([FromQuery] int? dias = null, [FromQuery] int? horas = null)
    {
        await _servico.EnviarGeralAsync("Falha no processamento", "Ocorreu um erro ao sincronizar os dados com o GIGOV. A equipe de TI foi notificada.", "alerta", dias: dias, horas: horas);
        return Ok(new { sucesso = true, escopo = "Geral" });
    }

    // ──────────────────────────────────────────────────────────────────────────
    // TESTES — INDIVIDUAIS (por usuário)
    // ──────────────────────────────────────────────────────────────────────────

    /// <summary>Envia notificação APENAS para Ana Lima (usuario-a).</summary>
    [HttpPost("teste/individual/usuario-a")]
    public async Task<IActionResult> TesteIndividualUsuarioA([FromQuery] int? dias = null, [FromQuery] int? horas = null)
    {
        await _servico.EnviarIndividualAsync(
            "Contrato atribuído a você",
            "O contrato DSB-002 — Campina Grande foi atribuído à analista Ana Lima para revisão urgente.",
            "informacao",
            "usuario-a",
            dias: dias, horas: horas);
        return Ok(new { sucesso = true, escopo = "Individual", destinatario = "usuario-a" });
    }

    /// <summary>Envia notificação APENAS para Bruno Costa (usuario-b).</summary>
    [HttpPost("teste/individual/usuario-b")]
    public async Task<IActionResult> TesteIndividualUsuarioB([FromQuery] int? dias = null, [FromQuery] int? horas = null)
    {
        await _servico.EnviarIndividualAsync(
            "Aprovação pendente — sua ação é necessária",
            "O desembolso DSB-005 — Prefeitura de Aracaju aguarda aprovação do gestor. Prazo: hoje às 18h.",
            "alerta",
            "usuario-b",
            dias: dias, horas: horas);
        return Ok(new { sucesso = true, escopo = "Individual", destinatario = "usuario-b" });
    }

    /// <summary>
    /// Rajada mista: alterna entre notificações GERAIS e INDIVIDUAIS para demonstrar os dois escopos.
    /// </summary>
    [HttpPost("teste/rajada-mista")]
    public async Task<IActionResult> TesteRajadaMista([FromQuery] int? dias = null, [FromQuery] int? horas = null)
    {
        await _servico.EnviarGeralAsync("Novo contrato cadastrado", "DSB-007 incluído na fila de análise.", "informacao", dias: dias, horas: horas);
        await Task.Delay(800);

        await _servico.EnviarIndividualAsync("Tarefa atribuída a você", "DSB-002 foi atribuído para análise urgente — prazo: hoje.", "informacao", "usuario-a", dias: dias, horas: horas);
        await Task.Delay(800);

        await _servico.EnviarGeralAsync("Macro concluída", "6 contratos processados com sucesso.", "sucesso", dias: dias, horas: horas);
        await Task.Delay(800);

        await _servico.EnviarIndividualAsync("Aprovação pendente", "DSB-005 aguarda sua aprovação como gestor. Prazo: 18h.", "alerta", "usuario-b", dias: dias, horas: horas);
        await Task.Delay(800);

        await _servico.EnviarGeralAsync("Pendência crítica identificada", "DSB-004 possui 7 validações inválidas.", "alerta", dias: dias, horas: horas);

        return Ok(new { sucesso = true, enviadas = 5, descricao = "3 gerais + 1 para usuario-a + 1 para usuario-b" });
    }

    // ──────────────────────────────────────────────────────────────────────────
    // STATUS
    // ──────────────────────────────────────────────────────────────────────────

    /// <summary>Verifica se o serviço está operacional.</summary>
    [HttpGet("status")]
    public IActionResult ObterStatus() =>
        Ok(new { online = true, timestamp = DateTime.UtcNow, banco = "SipubNotificacoes" });
}

public record RequisicaoEnvio(
    [property: DefaultValue("Desembolso aprovado ✓")] string Titulo,
    [property: DefaultValue("O desembolso DSB-001 — Prefeitura de Caruaru foi aprovado e liberado para pagamento.")] string Descricao,
    [property: DefaultValue("sucesso")] string Tipo = "informacao",
    [property: DefaultValue(7)] int? Dias = null,
    int? Horas = null
);
