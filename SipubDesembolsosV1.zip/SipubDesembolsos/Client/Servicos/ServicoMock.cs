using SipubDesembolsos.Client.Modelos;
using System.Globalization;

namespace SipubDesembolsos.Client.Servicos;

public static class ServicoMock
{
    private static readonly CultureInfo _culturaBR = new("pt-BR");

    // ──────────────────────────────────────────────────────────────────────────
    // FUNCIONÁRIOS
    // ──────────────────────────────────────────────────────────────────────────
    public static List<Funcionario> ObterFuncionarios() =>
    [
        new() { Id = 1, Nome = "Karina Souto",   Iniciais = "KS", Cor = "#005CA9" },
        new() { Id = 2, Nome = "Rafael Mendes",  Iniciais = "RM", Cor = "#6D28D9" },
        new() { Id = 3, Nome = "Ana Paula Lima", Iniciais = "AP", Cor = "#0E7490" },
        new() { Id = 4, Nome = "Bruno Costa",    Iniciais = "BC", Cor = "#065F46" },
        new() { Id = 5, Nome = "Tânia Ferreira", Iniciais = "TF", Cor = "#92400E" },
    ];

    // ──────────────────────────────────────────────────────────────────────────
    // DESEMBOLSOS
    // ──────────────────────────────────────────────────────────────────────────
    public static List<Desembolso> ObterDesembolsos() =>
    [
        new()
        {
            Id = "DSB-001", NumId = "0012483", Contrato = "0512.345/2022-01",
            Mutuario = "Prefeitura Municipal de Caruaru", Gigov = "GIGOV03",
            Valor = 1_450_000m, Fase = "2ª Medição",
            ValidacoesOk = 7, ValidacoesTotal = 10,
            Status = "pendencia",
            PrazoFinal = new DateTime(2025, 5, 16)
        },
        new()
        {
            Id = "DSB-002", NumId = "0012484", Contrato = "0512.346/2022-02",
            Mutuario = "Município de Campina Grande", Gigov = "GIGOV01",
            Valor = 870_000m, Fase = "1ª Medição",
            ValidacoesOk = 5, ValidacoesTotal = 10,
            Status = "pendente",
            PrazoFinal = new DateTime(2025, 5, 20)
        },
        new()
        {
            Id = "DSB-003", NumId = "0012485", Contrato = "0512.347/2022-03",
            Mutuario = "Prefeitura de Mossoró", Gigov = "GIGOV02",
            Valor = 2_100_000m, Fase = "3ª Medição",
            ValidacoesOk = 10, ValidacoesTotal = 10,
            Status = "aprovado",
            PrazoFinal = new DateTime(2025, 5, 12)
        },
        new()
        {
            Id = "DSB-004", NumId = "0012486", Contrato = "0512.348/2022-04",
            Mutuario = "Município de Feira de Santana", Gigov = "GIGOV05",
            Valor = 560_000m, Fase = "Final",
            ValidacoesOk = 3, ValidacoesTotal = 10,
            Status = "pendencia",
            PrazoFinal = new DateTime(2025, 5, 8)
        },
        new()
        {
            Id = "DSB-005", NumId = "0012487", Contrato = "0512.349/2022-05",
            Mutuario = "Prefeitura de Aracaju", Gigov = "GIGOV07",
            Valor = 1_230_000m, Fase = "1ª Medição",
            ValidacoesOk = 8, ValidacoesTotal = 10,
            Status = "pendente",
            PrazoFinal = new DateTime(2025, 5, 25)
        },
        new()
        {
            Id = "DSB-006", NumId = "0012488", Contrato = "0512.350/2022-06",
            Mutuario = "Município de Maceió", Gigov = "GIGOV04",
            Valor = 3_400_000m, Fase = "2ª Medição",
            ValidacoesOk = 10, ValidacoesTotal = 10,
            Status = "aprovado",
            PrazoFinal = new DateTime(2025, 5, 30)
        },
    ];

    // ──────────────────────────────────────────────────────────────────────────
    // VALIDAÇÕES (para o DSB-001; as demais usam subconjunto)
    // ──────────────────────────────────────────────────────────────────────────
    public static List<Validacao> ObterValidacoes(string idDesembolso = "DSB-001") =>
    [
        new()
        {
            Numero = 1, Titulo = "CND Municipal",
            Resultado = "Certidão válida — emitida em 03/03/2025, vence em 03/09/2025",
            Status = "valido", Icone = "bi-building",
            Detalhe = "A Certidão Negativa de Débitos Municipal foi emitida pela Prefeitura de Caruaru em 03/03/2025 e possui validade de 180 dias. Não foram encontrados débitos pendentes junto ao município."
        },
        new()
        {
            Numero = 2, Titulo = "Certidão INSS",
            Resultado = "Certidão válida — emitida em 15/02/2025",
            Status = "valido", Icone = "bi-shield-check",
            Detalhe = "A Certidão de Regularidade Fiscal junto ao INSS (CND) foi obtida via Receita Federal e está vigente. Não há débitos previdenciários em aberto."
        },
        new()
        {
            Numero = 3, Titulo = "Percentual de Desembolso",
            Resultado = "Percentual fora do intervalo permitido (62% vs. máx. 60%)",
            Status = "invalido", Icone = "bi-percent",
            Detalhe = "O percentual acumulado de desembolso (62%) excede o limite máximo permitido para esta fase (60%). É necessário adequação antes da liberação.",
            SubItens =
            [
                new() { Numero = "3a", Titulo = "% Acumulado de Obra",      Status = "valido",   Detalhe = "A medição acumulada de obra corresponde a 58% do total contratado, dentro da faixa esperada para a 2ª medição." },
                new() { Numero = "3b", Titulo = "% Máximo por Fase",         Status = "invalido", Detalhe = "O percentual máximo permitido para a 2ª medição é de 60%. O valor solicitado (62%) ultrapassa esse limite." },
                new() { Numero = "3c", Titulo = "Consistência Acumulada",    Status = "valido",   Detalhe = "Os valores acumulados de desembolso são consistentes com as medições anteriores." },
            ]
        },
        new()
        {
            Numero = 4, Titulo = "Sequência de Desembolso",
            Resultado = "Sequência correta — 2º desembolso após 1º aprovado",
            Status = "valido", Icone = "bi-list-ol",
            Detalhe = "O 1º desembolso foi aprovado em 12/11/2024 e o 2º está sendo solicitado dentro do prazo regulamentar. A sequência está correta."
        },
        new()
        {
            Numero = 5, Titulo = "Regularidade FGTS do Mutuário",
            Resultado = "Mutuário em situação regular junto ao FGTS",
            Status = "valido", Icone = "bi-person-check",
            Detalhe = "A Prefeitura Municipal de Caruaru está em situação regular junto ao FGTS, sem débitos em aberto. Certificado obtido em 01/04/2025."
        },
        new()
        {
            Numero = 6, Titulo = "Laudo de Medição do Engenheiro",
            Resultado = "Laudo aprovado com ressalvas na sub-item 6b",
            Status = "invalido", Icone = "bi-file-earmark-text",
            Detalhe = "O laudo de medição foi assinado pelo engenheiro responsável, mas a sub-validação de conformidade com o projeto original apresentou divergência.",
            SubItens =
            [
                new() { Numero = "6a", Titulo = "Assinatura do RT",            Status = "valido",   Detalhe = "O Responsável Técnico (RT) assinou o laudo conforme exigido." },
                new() { Numero = "6b", Titulo = "Conformidade com Projeto",    Status = "invalido", Detalhe = "O laudo indica execução de 62% da obra, mas o projeto aprovado prevê no máximo 60% para esta etapa." },
                new() { Numero = "6c", Titulo = "Registro no CREA/CAU",        Status = "valido",   Detalhe = "O profissional responsável está com o registro ativo no CREA-PE." },
            ]
        },
        new()
        {
            Numero = 7, Titulo = "Depósito de Contrapartida",
            Resultado = "Contrapartida depositada — R$ 290.000,00 em 05/04/2025",
            Status = "valido", Icone = "bi-bank",
            Detalhe = "A contrapartida obrigatória de 20% do valor do investimento foi depositada na conta vinculada em 05/04/2025, conforme comprovante anexado ao processo."
        },
        new()
        {
            Numero = 8, Titulo = "Prazo Contratual",
            Resultado = "Contrato com prazo vencido — venceu em 30/03/2025",
            Status = "invalido", Icone = "bi-calendar-x",
            Detalhe = "O prazo de execução contratual expirou em 30/03/2025. É necessário o aditamento do contrato antes da liberação do desembolso.",
            ComentarioPreenchido = new Comentario
            {
                Tipo = "negativo",
                Texto = "Contrato vencido. Mutuário foi notificado para apresentar documentação de prorrogação até 25/05/2025.",
                Autor = "Karina Souto",
                Timestamp = new DateTime(2025, 4, 18, 9, 30, 0)
            }
        },
        new()
        {
            Numero = 9, Titulo = "Regularidade Fiscal da Construtora",
            Resultado = "Certidão estadual da construtora com débito ativo de R$ 12.400,00",
            Status = "invalido", Icone = "bi-building-gear",
            Detalhe = "A construtora responsável pela obra apresenta débito ativo de R$ 12.400,00 junto à SEFAZ-PE, " +
                      "conforme consulta realizada em 02/05/2025. A liberação do desembolso está condicionada à " +
                      "regularização fiscal ou à apresentação de certidão positiva com efeito de negativa."
        },
        new()
        {
            Numero = 10, Titulo = "Comunicação ao SCPO",
            Resultado = "Comunicação ao Ministério do Trabalho realizada",
            Status = "valido", Icone = "bi-send-check",
            Detalhe = "A comunicação ao Sistema de Controle de Projetos e Obras (SCPO) do Ministério do Trabalho foi realizada em 10/04/2025, dentro do prazo regulamentar."
        },
    ];

    // ──────────────────────────────────────────────────────────────────────────
    // DETALHE DO CONTRATO
    // ──────────────────────────────────────────────────────────────────────────
    public static DetalheContrato ObterDetalheContrato(Desembolso row)
    {
        if (row.Id == "DSB-001")
        {
            return new DetalheContrato
            {
                Id = "DSB-001",
                Gigov = "GIG-2022-04512",
                NumeroContrato = "0512.345/2022-01",
                Mutuario = new() { Nome = "Prefeitura Municipal de Caruaru", Tipo = "Município" },
                Af = new() { Nome = "Agência Nordeste — Recife", Sigla = "AF/REC" },
                Financiamento = new()
                {
                    Programa           = "Pró-Moradia",
                    ValorInvestimento  = 1_812_500m,
                    ValorFinanciamento = 1_450_000m,
                    NumeroDesembolso   = "2º",
                    Fase               = "2ª Medição",
                    PercentualObra     = 62m,
                    Amortizacao        = "SAC / TR",
                    PercentualContrapartida = 20m
                }
            };
        }

        // Gera dados plausíveis para os demais desembolsos
        var seed = row.Id.GetHashCode();
        var programas = new[] { "Pró-Moradia", "Saneamento", "Mobilidade Urbana", "Infraestrutura" };
        var afs = new[]
        {
            new DadosAf { Nome = "Agência Norte — Belém",       Sigla = "AF/BEL" },
            new DadosAf { Nome = "Agência Centro-Oeste — BSB",  Sigla = "AF/BSB" },
            new DadosAf { Nome = "Agência Sul — Porto Alegre",  Sigla = "AF/POA" },
        };

        return new DetalheContrato
        {
            Id             = row.Id,
            Gigov          = row.Gigov,
            NumeroContrato = row.Contrato,
            Mutuario       = new() { Nome = row.Mutuario, Tipo = "Município" },
            Af             = afs[Math.Abs(seed) % afs.Length],
            Financiamento  = new()
            {
                Programa           = programas[Math.Abs(seed) % programas.Length],
                ValorInvestimento  = row.Valor * 1.25m,
                ValorFinanciamento = row.Valor,
                NumeroDesembolso   = row.Fase.Contains("1") ? "1º" : row.Fase.Contains("2") ? "2º" : "3º",
                Fase               = row.Fase,
                PercentualObra     = 45m + (Math.Abs(seed) % 30),
                Amortizacao        = "SAC / TR",
                PercentualContrapartida = 20m
            }
        };
    }

    // ──────────────────────────────────────────────────────────────────────────
    // UTILITÁRIOS DE FORMATAÇÃO
    // ──────────────────────────────────────────────────────────────────────────
    public static string FormatarBRL(decimal valor) =>
        valor.ToString("C", _culturaBR);

    public static string FormatarPrazo(DateTime data)
    {
        string[] meses = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];
        return $"{data.Day} {meses[data.Month - 1]}";
    }

    public static string FormatarTempo(DateTime timestamp)
    {
        var diff = DateTime.Now - timestamp;
        if (diff.TotalMinutes < 1)   return "agora";
        if (diff.TotalMinutes < 60)  return $"{(int)diff.TotalMinutes}min atrás";
        if (diff.TotalHours   < 24)  return $"{(int)diff.TotalHours}h atrás";
        return timestamp.ToString("dd/MM/yyyy HH:mm");
    }
}
