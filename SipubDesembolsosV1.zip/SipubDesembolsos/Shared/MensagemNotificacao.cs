namespace SipubDesembolsos.Shared;

public class MensagemNotificacao
{
    public int      Id        { get; set; }
    public string   Titulo    { get; set; } = string.Empty;
    public string   Descricao { get; set; } = string.Empty;
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    public string   Tipo      { get; set; } = "informacao"; // informacao | sucesso | alerta
    public string   Escopo    { get; set; } = "Individual"; // Geral | Individual
    public DateTime ExpiraEm  { get; set; }
}
