namespace SipubDesembolsos.Shared;

public class NotificacaoDto
{
    public int      Id        { get; set; }
    public string   Titulo    { get; set; } = "";
    public string   Descricao { get; set; } = "";
    public string   Tipo      { get; set; } = "";
    public string   Escopo    { get; set; } = "";
    public DateTime CriadaEm { get; set; }
    public bool     Lida      { get; set; }
}
